# Learnty Mobile Testing Instructions

## Overview
Two versions of Learnty Week 1 have been deployed for mobile testing:

1. **Flutter Web**: https://0bv5dv5ak3et.space.minimax.io
2. **React Mobile**: https://5xt8ocabt3r8.space.minimax.io

## Testing Objective
Determine which version works better on mobile Chrome browsers and identify any issues.

## Test Environment
- **Device**: Mobile phone or tablet
- **Browser**: Chrome for mobile
- **Viewport**: Portrait orientation recommended

## Complete Test Pathway

### Step 1: Initial Load & Onboarding
**Actions:**
1. Open the application URL in mobile Chrome
2. Observe the loading time and any errors
3. View the onboarding screen (should show 4 slides)
4. Swipe or tap through all 4 onboarding slides:
   - Slide 1: "Welcome to Learnty"
   - Slide 2: "Small Simple Steps"
   - Slide 3: "Track Your Progress"
   - Slide 4: "Build Your Future"
5. Tap "Get Started" button

**Expected Results:**
- App loads within 2-3 seconds
- All 4 slides display correctly with images/icons and text
- Smooth navigation between slides
- "Get Started" button is clickable and responsive

**Document:**
- Loading time: _____ seconds
- Any visual glitches or layout issues: _____
- Touch responsiveness (smooth/laggy): _____

---

### Step 2: User Registration
**Actions:**
1. On the auth screen, ensure "Sign Up" tab is selected
2. Enter test credentials:
   - Email: `mobiletest@test.com`
   - Password: `Test123!@#`
   - Confirm Password: `Test123!@#`
3. Tap "Sign Up" button
4. Observe the registration process

**Expected Results:**
- Form fields accept input smoothly
- Validation shows error messages for invalid input
- Successful registration navigates to dashboard
- Loading indicator appears during registration

**Document:**
- Input field responsiveness: _____
- Validation messages work correctly: _____
- Registration successful: Yes/No
- Any errors encountered: _____

---

### Step 3: Dashboard Display
**Actions:**
1. After successful registration/login, view the dashboard
2. Check all dashboard elements:
   - Stats cards (XP, Level, Streak, Achievements)
   - Quick action buttons
   - Navigation bar at bottom (Dashboard, Books, Projects, Review, Focus)
3. Scroll through the dashboard content

**Expected Results:**
- Dashboard loads with user data (0 XP, Level 1, 0 day streak, 0 achievements)
- All stats cards display properly
- Quick action buttons are visible and properly sized
- Bottom navigation is fixed and accessible
- Smooth scrolling

**Document:**
- Dashboard loads correctly: Yes/No
- Stats display properly: _____
- Navigation bar accessible: Yes/No
- Layout issues: _____

---

### Step 4: Profile Navigation
**Actions:**
1. Tap the "Profile" icon in bottom navigation
2. View the profile screen
3. Check profile information display:
   - Avatar placeholder or uploaded image
   - Email address
   - XP and Level display
   - Stats summary

**Expected Results:**
- Profile screen loads quickly
- All profile information displays correctly
- Avatar area is visible
- Layout is responsive on mobile screen

**Document:**
- Navigation successful: Yes/No
- Profile data displays correctly: _____
- Layout issues: _____

---

### Step 5: Profile Picture Upload
**Actions:**
1. On profile screen, tap "Change Avatar" or avatar area
2. Select an image from your device (use a small test image)
3. Observe the upload process
4. Check if avatar updates successfully

**Expected Results:**
- File picker opens on mobile device
- Image upload shows progress indicator
- Avatar updates after successful upload
- Image displays correctly (not distorted)

**Document:**
- File picker works: Yes/No
- Upload successful: Yes/No
- Upload time: _____ seconds
- Avatar displays correctly: Yes/No
- Any errors: _____

---

### Step 6: Profile Editing
**Actions:**
1. Tap "Edit Profile" button
2. Try editing user information (if available)
3. Save changes
4. Verify changes persist

**Expected Results:**
- Edit form displays correctly
- Input fields are accessible
- Save button works
- Changes are saved successfully

**Document:**
- Edit form works: Yes/No
- Save successful: Yes/No
- Any issues: _____

---

### Step 7: Additional Navigation Testing
**Actions:**
1. Navigate through all bottom navigation items:
   - Dashboard
   - Books (placeholder)
   - Projects (placeholder)
   - Review (placeholder)
   - Focus (placeholder)
2. Test back navigation
3. Test logout functionality (if accessible)

**Expected Results:**
- All navigation items are clickable
- Screens load without errors
- Back button works correctly
- Smooth transitions between screens

**Document:**
- All nav items work: Yes/No
- Any broken links: _____
- Navigation feel (smooth/janky): _____

---

### Step 8: Responsive Design Check
**Actions:**
1. Rotate device to landscape orientation
2. Check if layout adapts properly
3. Return to portrait orientation
4. Zoom in and out slightly
5. Check text readability
6. Check touch target sizes

**Expected Results:**
- Layout adapts to orientation changes
- Text is readable at default zoom
- Buttons and links are easily tappable (minimum 44x44px)
- No horizontal scrolling required
- Content doesn't overflow or get cut off

**Document:**
- Responsive to orientation: Yes/No
- Text readability: Good/Fair/Poor
- Touch targets adequate: Yes/No
- Layout issues: _____

---

## Comparison Checklist

After testing BOTH applications, compare:

| Aspect | Flutter Web | React Mobile | Winner |
|--------|-------------|--------------|--------|
| Initial Load Time | _____ | _____ | _____ |
| Onboarding Smoothness | _____ | _____ | _____ |
| Form Input Responsiveness | _____ | _____ | _____ |
| Dashboard Performance | _____ | _____ | _____ |
| Navigation Feel | _____ | _____ | _____ |
| Avatar Upload | _____ | _____ | _____ |
| Overall Mobile Experience | _____ | _____ | _____ |
| Any Crashes/Errors | _____ | _____ | _____ |

## Known Differences

### Flutter Web (https://0bv5dv5ak3et.space.minimax.io)
- Built with Flutter framework compiled to web
- May have larger initial bundle size
- Renders using CanvasKit or HTML renderer
- Potential issues: Touch gestures, text input on mobile browsers

### React Mobile (https://5xt8ocabt3r8.space.minimax.io)
- Built with React + TypeScript + Tailwind CSS
- Optimized for mobile-first design
- Native web interactions
- Progressive Web App (PWA) capable
- Should have better mobile browser compatibility

## Reporting Results

Please report back with:

1. **Which version works better overall?**
2. **Specific issues encountered with each version**
3. **Performance comparison (loading, smoothness)**
4. **Any features that don't work on mobile**
5. **Your recommendation for which to use going forward**

## Test Credentials

Use these credentials for both applications:
- **Email**: `mobiletest@test.com`
- **Password**: `Test123!@#`

Note: If this email is already registered, you can either:
- Use the login flow instead of registration
- Try a different email like `mobiletest2@test.com`

## Additional Notes

- Both applications connect to the same Supabase backend
- User data is shared between both versions
- Test on a real mobile device for best results (not desktop browser mobile emulation)
- Clear browser cache between tests if needed
