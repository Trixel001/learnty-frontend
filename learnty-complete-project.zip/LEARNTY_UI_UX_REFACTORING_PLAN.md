# Learnty Mobile App: Comprehensive UI/UX Refactoring Plan

**Objective**: Transform the current complex, cluttered interface into a "super simple to use" mobile learning application that maintains all functionality while dramatically improving usability.

---

## 📋 **Part 1: Current Implementation Analysis & Critical Flaws**

### **1. Navigation & Hierarchy Issues**

**Current State (6 Bottom Navigation Items):**
- Dashboard (Home/Overview)
- Books (Book Library)
- Learning (Learning Paths)
- Review (Flashcards)
- Focus (Timer Sessions)
- Menu (Profile/Settings - confusingly labeled)

**Problems Identified:**
- **Cognitive Overload**: 6 tabs exceed the optimal 3-5 item limit for mobile navigation
- **Poor Feature Grouping**: Related features (Books/Projects, Learning/Review) are separated
- **Confusing Labels**: "Menu" tab with User icon doesn't match user expectations
- **Missing Route**: `/projects` referenced in Dashboard but not defined in App.tsx

### **2. Redundant Information Architecture**

**Learning Stats Duplication:**
- **Dashboard.tsx**: Progress rings showing Streak, Total XP, Level (lines 123-148)
- **Menu.tsx**: Identical stats displayed again (lines 59-78)

**Impact**: Users see the same information twice, creating confusion and cognitive noise.

### **3. Misleading Affordance - Critical FAB Issue**

**Current FAB Implementation:**
```typescript
// Dashboard.tsx lines 351-363
<motion.button
  onClick={() => navigate('/books')}  // ❌ WRONG: Plus icon should ADD, not navigate
  className="fixed bottom-20 right-4 w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600..."
>
  <Plus className="w-6 h-6 text-white" />
</motion.button>
```

**Problems:**
- **Visual Mismatch**: Plus icon implies "Add/Create" action
- **Action Mismatch**: Actually navigates to Books list (browsing, not adding)
- **Poor UX**: Users expect to create something when seeing a plus icon

### **4. Visual Clutter & Space Competition**

**Current Issues:**
- **FAB Competition**: FAB (bottom-right) and AIChatbot (bottom-right) compete for same space
- **No Clear Hierarchy**: No visual prioritization of primary actions
- **Mobile Space Waste**: Multiple floating elements reduce usable screen real estate

### **5. Navigation Broken Links**

**Missing Route Definition:**
- Dashboard "My Projects" quick action: `path: '/projects'`
- App.tsx: No corresponding route defined
- Impact: Button click leads to 404 or error

---

## 🏗️ **Part 2: Proposed Information Architecture Refactoring**

### **New 5-Tab Navigation Structure**

**1. Dashboard** (Home/Overview)
- **Purpose**: Central hub with stats, quick actions, progress overview
- **Icons**: `LayoutDashboard`
- **Unchanged**: Primary landing page functionality

**2. Library** (Books + Projects Consolidation)
- **Purpose**: Consolidated access to reading materials and project management
- **New Components**: 
  - Books sub-section
  - Projects sub-section
  - Unified search across both
- **Icons**: `BookOpen` (or create new Library icon)
- **Rationale**: Books and Projects are content consumption/creation tools

**3. Learn** (Learning Paths + Review Consolidation)
- **Purpose**: All active learning activities
- **New Components**:
  - Learning Paths sub-section
  - Review (Flashcards) sub-section
  - Unified progress tracking
- **Icons**: `Brain` or `GraduationCap`
- **Rationale**: Both are active learning experiences

**4. Focus** (Timer Sessions)
- **Purpose**: Dedicated focus/pomodoro timer functionality
- **Icons**: `Timer`
- **Unchanged**: Maintain current functionality

**5. Profile** (Clear User Management)
- **Purpose**: User profile, settings, app configuration
- **Components**: 
  - Avatar and profile editing
  - Settings and preferences
  - Notifications
  - Help & Support
  - Sign out
- **Icons**: `User`
- **Rationale**: Clear, intuitive labeling matches user expectations

### **Navigation Implementation Details**

**New navItems Array:**
```typescript
const navItems = [
  { path: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { path: '/library', icon: BookOpen, label: 'Library' },
  { path: '/learn', icon: Brain, label: 'Learn' },
  { path: '/focus', icon: Timer, label: 'Focus' },
  { path: '/profile', icon: User, label: 'Profile' }
]
```

### **Profile Page Refactoring**

**Remove Redundant Learning Stats:**
- **Current**: Menu.tsx displays identical stats as Dashboard
- **Proposed**: Remove Learning Stats section entirely from Profile
- **Rationale**: Stats belong on Dashboard where they're actionable, not in settings

**Enhanced Profile Content:**
- Avatar editing and profile information
- App settings and preferences
- Notification management
- Privacy and security settings
- Help and support access
- Account management (sign out)

---

## 🔧 **Part 3: Dashboard Refactoring Plan**

### **1. FAB (Floating Action Button) Fix**

**Current Problem:** Plus icon navigates to books instead of adding

**Proposed Solution: Smart Add Modal/Speed Dial**

```typescript
// New FAB Implementation
const [showAddModal, setShowAddModal] = useState(false)

<motion.button
  onClick={() => setShowAddModal(true)}  // ✅ Opens add menu
  className="fixed bottom-20 right-4 w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-600..."
>
  <Plus className="w-6 h-6 text-white" />
</motion.button>

// Add Modal/Speed Dial
{showAddModal && (
  <AddActionModal
    actions={[
      { icon: BookOpen, label: 'Add New Book', action: () => navigate('/books?action=add') },
      { icon: FolderOpen, label: 'New Project', action: () => navigate('/projects?action=create') },
      { icon: Timer, label: 'Start Focus Session', action: () => navigate('/focus?mode=quick') },
      { icon: Brain, label: 'Generate Study Plan', action: () => navigate('/learning-paths?action=create') }
    ]}
    onClose={() => setShowAddModal(false)}
  />
)}
```

**Benefits:**
- **Logical Affordance**: Plus icon now truly means "Add/Create"
- **Centralized Creation**: All primary creation actions in one place
- **Contextual Actions**: Relevant to current user state and progress

### **2. AIChatbot Repositioning**

**Current Problem:** Competes with FAB for bottom-right space

**Proposed Solutions (Priority Order):**

**Option A: Header Integration**
```typescript
// Add as persistent header icon
<div className="fixed top-4 right-4 z-40">
  <AIChatbotButton />
</div>
```

**Option B: Quick Actions Integration**
```typescript
// Integrate into Quick Actions section
const quickActions = [
  // ... existing actions
  {
    icon: MessageCircle,
    title: 'AI Assistant',
    subtitle: 'Get learning help',
    action: () => setShowChatbot(true)
  }
]
```

**Option C: Profile Integration**
- Move chatbot functionality to Profile page as "AI Learning Assistant"
- Matches user expectation of AI help in personal/learning context

**Recommendation:** Option A for maximum visibility without space conflicts

### **3. Dashboard Layout Improvements**

**Streamlined Information Hierarchy:**
1. **Header**: User greeting and motivational quote (unchanged)
2. **Quick Actions**: Prominently displayed creation and access actions
3. **Progress Rings**: Key metrics in compact format
4. **Secondary Content**: Streak calendar, learning chart, achievements

**Mobile-First Optimizations:**
- Reduce FAB size on small screens
- Optimize touch targets (44px minimum)
- Ensure sufficient spacing between interactive elements
- Prioritize content based on user goals (learn > review > browse)

---

## 🛠️ **Part 4: App.tsx Router & Navigation Implementation**

### **1. Missing Route Addition**

**Add Projects Route:**
```typescript
// Add to lazy loading section (after FocusAnalytics)
const Projects = React.lazy(() => 
  import('./pages/Projects').catch(err => {
    console.error('Failed to load Projects component:', err)
    return { default: () => <div className="p-4 text-red-600">Failed to load Projects component: {err.message}</div> }
  })
)

// Add route definition (after learning-paths route)
<Route path="/projects" element={
  <ProtectedRoute>
    <ErrorBoundary>
      <React.Suspense fallback={
        <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center">
          <BookLoader />
        </div>
      }>
        <Projects />
      </React.Suspense>
    </ErrorBoundary>
  </ProtectedRoute>
} />
```

### **2. Bottom Navigation Update**

**Complete BottomNav Replacement:**
```typescript
function BottomNav() {
  const location = useLocation()
  const navigate = useNavigate()

  const navItems = [
    { path: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
    { path: '/library', icon: BookOpen, label: 'Library' },
    { path: '/learn', icon: Brain, label: 'Learn' },
    { path: '/focus', icon: Timer, label: 'Focus' },
    { path: '/profile', icon: User, label: 'Profile' }
  ]

  const showNav = navItems.some(item => location.pathname.startsWith(item.path)) || 
                  location.pathname.startsWith('/focus/analytics')
  
  if (!showNav) return null

  // Rest of component unchanged...
}
```

### **3. New Library Page Implementation**

**Library.tsx Structure:**
```typescript
// New comprehensive Library page
export default function Library() {
  const [activeTab, setActiveTab] = useState('books')
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      {/* Header with tab navigation */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 px-6 pt-12 pb-4">
        <h1 className="text-2xl font-bold text-white mb-4">Library</h1>
        <div className="flex gap-4">
          <button onClick={() => setActiveTab('books')} className={activeTab === 'books' ? 'text-white font-semibold' : 'text-white/70'}>
            Books
          </button>
          <button onClick={() => setActiveTab('projects')} className={activeTab === 'projects' ? 'text-white font-semibold' : 'text-white/70'}>
            Projects
          </button>
        </div>
      </div>
      
      {/* Tab Content */}
      {activeTab === 'books' && <BooksSection />}
      {activeTab === 'projects' && <ProjectsSection />}
    </div>
  )
}
```

### **4. New Learn Page Implementation**

**Learn.tsx Structure:**
```typescript
// New consolidated learning page
export default function Learn() {
  const [activeTab, setActiveTab] = useState('paths')
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      {/* Header with tab navigation */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 px-6 pt-12 pb-4">
        <h1 className="text-2xl font-bold text-white mb-4">Learn</h1>
        <div className="flex gap-4">
          <button onClick={() => setActiveTab('paths')} className={activeTab === 'paths' ? 'text-white font-semibold' : 'text-white/70'}>
            Learning Paths
          </button>
          <button onClick={() => setActiveTab('review')} className={activeTab === 'review' ? 'text-white font-semibold' : 'text-white/70'}>
            Review Cards
          </button>
        </div>
      </div>
      
      {/* Tab Content */}
      {activeTab === 'paths' && <LearningPathsSection />}
      {activeTab === 'review' && <ReviewSection />}
    </div>
  )
}
```

### **5. Profile Page Cleanup**

**Remove Redundant Stats:**
```typescript
// In Profile.tsx, remove this entire section:
const stats = [
  {
    icon: Star,
    label: 'Total XP',
    value: profile?.total_xp || 0,
    color: 'from-blue-500 to-purple-500'
  },
  // ... other stats
]
```

---

## 📊 **Part 5: Comprehensive Benefits & Justification**

### **Cognitive Load Reduction**

**Before (6 tabs):**
- Users must scan 6 navigation options
- Related features scattered across different tabs
- Mixed mental models (content vs. actions vs. settings)

**After (5 tabs):**
- Reduced to optimal 5-tab structure
- Related features logically grouped
- Clear mental model: Dashboard → Access → Learn → Focus → Profile

### **Improved Discoverability**

**Feature Accessibility Improvements:**
- **Projects**: Now accessible via Library tab (currently broken link)
- **Profile**: Clear User icon labeling eliminates confusion
- **All Features**: Logical grouping reduces search time

**Enhanced User Flow:**
```
Current: Dashboard → Click "My Projects" → 404 Error
Proposed: Dashboard → Library Tab → Projects Sub-section
```

### **UI Flaw Resolutions**

**Critical Fixes:**
1. **FAB Logic**: Plus icon now truly adds/creates
2. **Navigation Clarity**: Profile clearly labeled instead of "Menu"
3. **Space Optimization**: No more bottom-right competition
4. **Broken Links**: All navigation paths now functional

### **Functionality Preservation**

**Zero Feature Loss:**
- All existing features maintained
- Enhanced accessibility through better organization
- Improved discoverability without removal
- Feature consolidation improves rather than reduces functionality

### **Implementation Priority Matrix**

**Phase 1 (High Impact, Low Effort):**
- Fix FAB functionality
- Add missing `/projects` route
- Update navigation labels

**Phase 2 (High Impact, Medium Effort):**
- Create Library and Learn consolidation pages
- Reposition AIChatbot
- Remove redundant stats from Profile

**Phase 3 (Enhancement):**
- Implement Add Action Modal
- Fine-tune mobile optimizations
- Add analytics for usage tracking

### **Success Metrics**

**Quantitative Improvements:**
- Navigation options: 6 → 5 tabs (-17%)
- User clicks to find projects: ∞ (broken) → 2 clicks
- FAB action accuracy: 0% (misleading) → 100% (logical)

**Qualitative Improvements:**
- Reduced cognitive load through logical grouping
- Enhanced mobile usability
- Improved feature discoverability
- Clearer user mental models

---

## 🎯 **Conclusion**

This refactoring plan transforms Learnty from a complex, feature-cluttered application into a streamlined, intuitive learning companion. By consolidating related features, fixing critical UX flaws, and implementing logical navigation hierarchies, we achieve the "super simple to use" objective while maintaining all existing functionality.

**Key Achievements:**
- **17% reduction** in navigation complexity
- **100% feature accessibility** (vs. current broken projects link)
- **Logical feature grouping** improves learnability
- **Mobile-first optimization** enhances usability

The proposed changes align with mobile design best practices and user psychology, ensuring that the application becomes more intuitive and efficient for daily learning workflows.
