# Learnty App: Step-by-Step Implementation Guide

**This guide provides exact code changes needed to implement the UI/UX refactoring plan.**

---

## 🚀 **Phase 1: Critical Fixes (Start Here)**

### **1. Fix Missing /projects Route**

**File: `/src/App.tsx`**

**Add Projects lazy import (after FocusAnalytics, line 52):**
```typescript
const Projects = React.lazy(() => 
  import('./pages/Projects').catch(err => {
    console.error('Failed to load Projects component:', err)
    return { default: () => <div className="p-4 text-red-600">Failed to load Projects component: {err.message}</div> }
  })
)
```

**Add Projects route (after /learning-paths route, around line 260):**
```typescript
<Route path="/projects" element={
  <ProtectedRoute>
    <ErrorBoundary>
      <React.Suspense fallback={
        <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center">
          <BookLoader />
        </div>
      }>
        <Projects />
      </React.Suspense>
    </ErrorBoundary>
  </ProtectedRoute>
} />
```

### **2. Fix FAB (Floating Action Button)**

**File: `/src/pages/Dashboard.tsx`**

**Replace the existing FAB (lines 351-363) with:**
```typescript
const [showAddModal, setShowAddModal] = useState(false)
const [showFab, setShowFab] = useState(false)

// Add Action Modal Component (add before return statement)
const AddActionModal = ({ actions, onClose }: { actions: any[], onClose: () => void }) => (
  <motion.div
    initial={{ opacity: 0 }}
    animate={{ opacity: 1 }}
    exit={{ opacity: 0 }}
    className="fixed inset-0 bg-black/50 flex items-end justify-center z-50"
    onClick={onClose}
  >
    <motion.div
      initial={{ y: 100 }}
      animate={{ y: 0 }}
      exit={{ y: 100 }}
      className="bg-white rounded-t-3xl p-6 w-full max-w-md mx-4 mb-safe"
      onClick={(e) => e.stopPropagation()}
    >
      <div className="w-12 h-1 bg-gray-300 rounded-full mx-auto mb-4"></div>
      <h3 className="text-lg font-bold text-gray-900 mb-4 text-center">Create New</h3>
      <div className="grid grid-cols-2 gap-3">
        {actions.map((action, index) => {
          const Icon = action.icon
          return (
            <motion.button
              key={action.label}
              whileTap={{ scale: 0.95 }}
              onClick={() => {
                action.action()
                onClose()
              }}
              className="flex flex-col items-center gap-2 p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors"
            >
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-500 rounded-xl flex items-center justify-center">
                <Icon className="w-5 h-5 text-white" />
              </div>
              <span className="text-sm font-medium text-gray-900 text-center">{action.label}</span>
            </motion.button>
          )
        })}
      </div>
      <button
        onClick={onClose}
        className="w-full mt-4 py-3 text-gray-600 font-medium"
      >
        Cancel
      </button>
    </motion.div>
  </motion.div>
)

// Replace existing FAB with:
{showFab && (
  <>
    <motion.button
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.9 }}
      onClick={() => setShowAddModal(true)}
      className="fixed bottom-20 sm:bottom-24 right-4 sm:right-6 w-12 h-12 sm:w-14 sm:h-14 bg-gradient-to-br from-green-500 to-emerald-600 rounded-full shadow-xl flex items-center justify-center z-40"
    >
      <Plus className="w-6 h-6 sm:w-7 sm:h-7 text-white" />
    </motion.button>

    {showAddModal && (
      <AddActionModal
        actions={[
          {
            icon: BookOpen,
            label: 'Add Book',
            action: () => navigate('/books?action=add')
          },
          {
            icon: FolderOpen,
            label: 'New Project',
            action: () => navigate('/projects?action=create')
          },
          {
            icon: Timer,
            label: 'Focus Session',
            action: () => navigate('/focus?mode=quick')
          },
          {
            icon: Sparkles,
            label: 'Study Plan',
            action: () => navigate('/learning-paths?action=create')
          }
        ]}
        onClose={() => setShowAddModal(false)}
      />
    )}
  </>
)}
```

### **3. Move AIChatbot to Top-Right**

**File: `/src/pages/Dashboard.tsx`**

**Replace the AIChatbot line (line 366) with:**
```typescript
{/* AI Assistant - Moved to top-right to avoid FAB conflicts */}
{showFab && (
  <div className="fixed top-4 right-4 z-40">
    <AIChatbot position="top-right" />
  </div>
)}
```

---

## 🏗️ **Phase 2: Navigation Restructure**

### **1. Update Bottom Navigation**

**File: `/src/App.tsx`**

**Replace navItems array (lines 91-98):**
```typescript
const navItems = [
  { path: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { path: '/library', icon: BookOpen, label: 'Library' },
  { path: '/learn', icon: Brain, label: 'Learn' },
  { path: '/focus', icon: Timer, label: 'Focus' },
  { path: '/profile', icon: User, label: 'Profile' }
]
```

**Update showNav condition (lines 101-104):**
```typescript
const showNav = navItems.some(item => location.pathname.startsWith(item.path)) || 
                location.pathname.startsWith('/focus/analytics')
```

### **2. Add Missing Imports**

**File: `/src/App.tsx` (add to imports at top):**
```typescript
import { Brain } from 'lucide-react'
```

### **3. Update needsPadding Array**

**File: `/src/App.tsx` (line 213):**
```typescript
const needsPadding = user && hasCompletedOnboarding && 
  ['/dashboard', '/books', '/learning-paths', '/projects', '/review', '/profile', '/library', '/learn', '/focus'].some(path => location.pathname.startsWith(path))
```

---

## 📱 **Phase 3: Create New Consolidated Pages**

### **1. Create Library Page**

**File: `/src/pages/Library.tsx`**
```typescript
import { useState } from 'react'
import { motion } from 'framer-motion'
import { useNavigate } from 'react-router-dom'
import { BookOpen, FolderOpen, Search, Plus } from 'lucide-react'
import BookUpload from '@/components/BookUpload'
import Projects from './Projects'

export default function Library() {
  const [activeTab, setActiveTab] = useState('books')
  const navigate = useNavigate()

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 pb-24">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 px-6 pt-12 pb-4">
        <h1 className="text-2xl font-bold text-white mb-4">Library</h1>
        
        {/* Tab Navigation */}
        <div className="flex gap-4">
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => setActiveTab('books')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl transition-all ${
              activeTab === 'books' 
                ? 'bg-white/20 text-white font-semibold' 
                : 'text-white/70 hover:text-white'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>Books</span>
          </motion.button>
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => setActiveTab('projects')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl transition-all ${
              activeTab === 'projects' 
                ? 'bg-white/20 text-white font-semibold' 
                : 'text-white/70 hover:text-white'
            }`}
          >
            <FolderOpen className="w-4 h-4" />
            <span>Projects</span>
          </motion.button>
        </div>
      </div>

      {/* Tab Content */}
      <div className="px-6 pt-6">
        {activeTab === 'books' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-lg font-semibold text-gray-900">Your Books</h2>
              <motion.button
                whileTap={{ scale: 0.95 }}
                onClick={() => navigate('/books?action=add')}
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-xl font-medium"
              >
                <Plus className="w-4 h-4" />
                Add Book
              </motion.button>
            </div>
            <BookUpload />
          </div>
        )}
        
        {activeTab === 'projects' && <Projects />}
      </div>
    </div>
  )
}
```

### **2. Create Learn Page**

**File: `/src/pages/Learn.tsx`**
```typescript
import { useState } from 'react'
import { motion } from 'framer-motion'
import { useNavigate } from 'react-router-dom'
import { Brain, MapPin, RotateCcw, Plus } from 'lucide-react'

export default function Learn() {
  const [activeTab, setActiveTab] = useState('paths')
  const navigate = useNavigate()

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 pb-24">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 px-6 pt-12 pb-4">
        <h1 className="text-2xl font-bold text-white mb-4">Learn</h1>
        
        {/* Tab Navigation */}
        <div className="flex gap-4">
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => setActiveTab('paths')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl transition-all ${
              activeTab === 'paths' 
                ? 'bg-white/20 text-white font-semibold' 
                : 'text-white/70 hover:text-white'
            }`}
          >
            <MapPin className="w-4 h-4" />
            <span>Learning Paths</span>
          </motion.button>
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => setActiveTab('review')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl transition-all ${
              activeTab === 'review' 
                ? 'bg-white/20 text-white font-semibold' 
                : 'text-white/70 hover:text-white'
            }`}
          >
            <RotateCcw className="w-4 h-4" />
            <span>Review Cards</span>
          </motion.button>
        </div>
      </div>

      {/* Tab Content */}
      <div className="px-6 pt-6">
        {activeTab === 'paths' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-lg font-semibold text-gray-900">Your Learning Paths</h2>
              <motion.button
                whileTap={{ scale: 0.95 }}
                onClick={() => navigate('/learning-paths?action=create')}
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-xl font-medium"
              >
                <Plus className="w-4 h-4" />
                New Path
              </motion.button>
            </div>
            {/* Learning Paths content will go here */}
          </div>
        )}
        
        {activeTab === 'review' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-lg font-semibold text-gray-900">Review Cards</h2>
              <motion.button
                whileTap={{ scale: 0.95 }}
                onClick={() => navigate('/review?mode=quick')}
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-xl font-medium"
              >
                <Brain className="w-4 h-4" />
                Start Review
              </motion.button>
            </div>
            {/* Review content will go here */}
          </div>
        )}
      </div>
    </div>
  )
}
```

### **3. Add Routes for New Pages**

**File: `/src/App.tsx`**

**Add lazy imports (after existing lazy imports):**
```typescript
const Library = React.lazy(() => 
  import('./pages/Library').catch(err => {
    console.error('Failed to load Library component:', err)
    return { default: () => <div className="p-4 text-red-600">Failed to load Library component: {err.message}</div> }
  })
)

const Learn = React.lazy(() => 
  import('./pages/Learn').catch(err => {
    console.error('Failed to load Learn component:', err)
    return { default: () => <div className="p-4 text-red-600">Failed to load Learn component: {err.message}</div> }
  })
)
```

**Add routes (after existing routes):**
```typescript
<Route path="/library" element={
  <ProtectedRoute>
    <ErrorBoundary>
      <React.Suspense fallback={
        <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center">
          <BookLoader />
        </div>
      }>
        <Library />
      </React.Suspense>
    </ErrorBoundary>
  </ProtectedRoute>
} />

<Route path="/learn" element={
  <ProtectedRoute>
    <ErrorBoundary>
      <React.Suspense fallback={
        <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center">
          <BookLoader />
        </div>
      }>
        <Learn />
      </React.Suspense>
    </ErrorBoundary>
  </ProtectedRoute>
} />
```

---

## 🧹 **Phase 4: Profile Page Cleanup**

### **Remove Redundant Learning Stats**

**File: `/src/pages/Profile.tsx`**

**Remove stats array (lines 59-78):**
```typescript
// REMOVE THIS ENTIRE SECTION:
const stats = [
  {
    icon: Star,
    label: 'Total XP',
    value: profile?.total_xp || 0,
    color: 'from-blue-500 to-purple-500'
  },
  // ... rest of stats
]
```

**Remove Stats section rendering (find and remove the entire stats rendering block)**

---

## ✅ **Phase 5: Testing & Validation**

### **Checklist Before Deployment:**

1. **Navigation Testing:**
   - [ ] All 5 bottom nav tabs work correctly
   - [ ] Library tab shows Books and Projects sub-sections
   - [ ] Learn tab shows Learning Paths and Review sub-sections
   - [ ] Profile tab no longer shows redundant stats

2. **FAB Testing:**
   - [ ] FAB opens Add Action Modal
   - [ ] All modal actions work correctly
   - [ ] No conflicts with AIChatbot positioning

3. **Route Testing:**
   - [ ] `/projects` route now works (was previously broken)
   - [ ] All existing routes still function
   - [ ] Deep linking works for all pages

4. **Mobile Testing:**
   - [ ] FAB accessible on small screens
   - [ ] Tab navigation works on mobile
   - [ ] No horizontal scrolling issues

---

## 🚀 **Implementation Order**

**Week 1 (Critical Fixes):**
- Phase 1: Fix missing /projects route and FAB functionality
- Phase 2: Update bottom navigation structure

**Week 2 (Enhancement):**
- Phase 3: Create Library and Learn consolidation pages
- Phase 4: Profile page cleanup

**Week 3 (Polish):**
- Phase 5: Testing and mobile optimization
- Performance validation and final adjustments

---

This implementation guide provides exact code changes to transform Learnty into a streamlined, user-friendly application while maintaining all existing functionality.
