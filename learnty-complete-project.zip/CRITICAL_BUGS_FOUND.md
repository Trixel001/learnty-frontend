# CRITICAL BUGS FOUND IN LEARNTY MOBILE

## Analysis Date: 2025-10-30

## SUMMARY
The previous "bug fixes" were **INCOMPLETE** and introduced **NEW BUGS**. The application cannot build due to TypeScript errors, and the auth flow still blocks loading.

---

## BUG #1: Build Failure - Wrong Import Path
**File:** `src/components/DataWipe.tsx` Line 6  
**Severity:** CRITICAL (Prevents Build)  
**Status:** The application CANNOT BUILD

**Current Code:**
```typescript
import { useAuthStore } from '@/store/authStore'  // ❌ WRONG PATH
```

**Error:**
```
error TS2307: Cannot find module '@/store/authStore' or its corresponding type declarations.
```

**Fix:**
```typescript
import { useAuthStore } from '@/store/auth'  // ✅ CORRECT PATH
```

---

## BUG #2: TypeScript Type Errors in DataWipe
**File:** `src/components/DataWipe.tsx` Lines 44, 60, 76  
**Severity:** CRITICAL (Prevents Build)  
**Status:** The application CANNOT BUILD

**Current Code:**
```typescript
.in('book_id', supabase.from('books').select('id').eq('user_id', user.id))
```

**Error:**
```
error TS2345: Argument of type 'PostgrestFilterBuilder<...>' is not assignable to parameter of type 'readonly any[]'
```

**Root Cause:** Supabase `.in()` expects an array, not a query builder.

**Fix:** Get book IDs first, then use them in the IN clause:
```typescript
// Get book IDs first
const { data: userBooks } = await supabase
  .from('books')
  .select('id')
  .eq('user_id', user.id)

const bookIds = userBooks?.map(b => b.id) || []

if (bookIds.length > 0) {
  // Then use them in IN clause
  await supabase.from('book_chapters').delete().in('book_id', bookIds)
  await supabase.from('learning_sessions').delete().in('book_id', bookIds)
  await supabase.from('milestone_dependencies').delete().in('book_id', bookIds)
}
```

---

## BUG #3: Sign-In STILL Blocks Loading (Bug 4 Fix Was Incomplete)
**File:** `src/store/auth.ts` Lines 82-83  
**Severity:** HIGH (Defeats the entire purpose of Bug 4 fix)  
**Status:** User sees slow loading on sign-in

**Current Code:**
```typescript
signIn: async (email, password) => {
  set({ isLoading: true })
  try {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password })
    if (error) throw error
    if (!data.user) throw new Error('No user returned')

    console.log('[Auth] Sign in successful, user:', data.user.email)
    set({ user: data.user, lastActiveTime: Date.now() })
    
    // ❌ BLOCKING: Still waits for data before setting isLoading: false
    await get().refreshUserData()
    
    console.log('[Auth] Sign in complete with data loaded')
  } catch (error: any) {
    throw new Error(error.message || 'Sign in failed')
  } finally {
    set({ isLoading: false })  // ❌ Only set to false AFTER data loads
  }
}
```

**Why This Is Wrong:**
- User signs in → Loading spinner shows
- App waits for `refreshUserData()` (loads profile + achievements from database)
- Loading spinner disappears ONLY after profile loads
- **This is the OPPOSITE of what Bug 4 fix intended!**

**Fix:**
```typescript
signIn: async (email, password) => {
  set({ isLoading: true })
  try {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password })
    if (error) throw error
    if (!data.user) throw new Error('No user returned')

    console.log('[Auth] Sign in successful, user:', data.user.email)
    
    // ✅ SET USER AND STOP LOADING IMMEDIATELY
    set({ user: data.user, isLoading: false, lastActiveTime: Date.now() })
    
    // ✅ LOAD DATA IN BACKGROUND
    get().refreshUserData().catch(error => {
      console.error('[Auth] Background data refresh failed on sign-in:', error)
    })
    
    console.log('[Auth] Sign in complete, data loading in background')
  } catch (error: any) {
    set({ isLoading: false })
    throw new Error(error.message || 'Sign in failed')
  }
}
```

---

## BUG #4: PendingConfirmation Page May Not Show
**File:** `src/pages/Auth.tsx` Line 44  
**Severity:** MEDIUM  
**Status:** Navigation might fail silently

**Current Code:**
```typescript
if (isSignUp) {
  await signUp(email, password, fullName)
  toast.success('Account created! Please check your email to verify.')
  navigate('/pending-confirmation')
}
```

**Potential Issue:**
- If `signUp()` throws an error, navigation never happens
- User sees error toast but stays on auth page
- This is actually **CORRECT BEHAVIOR** (don't navigate on error)

**However, there's a subtle issue:**
- `signUp()` function in `auth.ts` might fail to create profile
- But doesn't throw error (lines 56-58 just log error)
- So user DOES navigate to pending-confirmation even if profile creation failed

**Fix in auth.ts:**
```typescript
signUp: async (email, password, fullName) => {
  set({ isLoading: true })
  try {
    const { data, error } = await supabase.auth.signUp({ email, password })
    
    if (error) throw error
    if (!data.user) throw new Error('No user returned')

    // Create profile via edge function
    const { error: profileError } = await supabase.functions.invoke('create-profile-trigger', {
      body: { userId: data.user.id, email, fullName }
    })

    // ✅ THROW ERROR if profile creation fails
    if (profileError) {
      console.error('Profile creation error:', profileError)
      throw new Error('Failed to create user profile: ' + profileError.message)
    }

    set({ user: data.user })
  } catch (error: any) {
    throw new Error(error.message || 'Sign up failed')
  } finally {
    set({ isLoading: false })
  }
}
```

---

## BUG #5: Silent Data Loading Failures
**File:** `src/store/auth.ts` Lines 283-286  
**Severity:** MEDIUM  
**Status:** User might be logged in but see NO data

**Current Code:**
```typescript
// *** FIX: SET USER AND STOP LOADING IMMEDIATELY ***
set({ user: session.user, isLoading: false, lastActiveTime: Date.now() })

// *** FIX: LOAD DATA IN THE BACKGROUND ***
get().refreshUserData().catch(error => {
    console.error('[Auth] Background data refresh failed:', error)
})
```

**Issue:**
- If `refreshUserData()` fails, error is only logged to console
- User sees empty dashboard with no profile data
- No visible error message to user

**Fix:**
```typescript
// *** FIX: SET USER AND STOP LOADING IMMEDIATELY ***
set({ user: session.user, isLoading: false, lastActiveTime: Date.now() })

// *** FIX: LOAD DATA IN THE BACKGROUND ***
get().refreshUserData().catch(error => {
    console.error('[Auth] Background data refresh failed:', error)
    // Show toast notification so user knows something went wrong
    import('react-hot-toast').then(({ default: toast }) => {
      toast.error('Failed to load profile data. Please refresh the page.')
    })
})
```

---

## ROOT CAUSE ANALYSIS

### Why Things Got Worse:
1. **Build errors were not tested** - The previous fixes introduced TypeScript errors that prevent compilation
2. **Incomplete understanding of the problem** - Bug 4 fix was applied to `initializeAuth()` but NOT to `signIn()`
3. **No error handling** - Background data loading has no user-facing error handling

### Why Data Isn't Loading:
1. Application cannot build due to TypeScript errors
2. Even if it built, `signIn()` still blocks on data loading
3. If data loading fails in background, user gets no feedback

### Why Pending Confirmation Page Doesn't Show:
1. It WILL show if signup succeeds
2. But if there's a build error, entire app breaks
3. Profile creation errors are silently swallowed

---

## FIX PRIORITY

**Priority 1 (CRITICAL - Prevents App from Running):**
- ✅ Fix DataWipe.tsx import path (Bug #1)
- ✅ Fix DataWipe.tsx TypeScript errors (Bug #2)

**Priority 2 (HIGH - User Experience Issues):**
- ✅ Fix signIn() blocking behavior (Bug #3)

**Priority 3 (MEDIUM - Edge Cases):**
- ✅ Add error handling for signUp profile creation (Bug #4)
- ✅ Add user feedback for background data loading failures (Bug #5)

---

## NEXT STEPS
1. Apply all fixes to source files
2. Run `npm run build` to verify compilation
3. Test sign-in flow manually
4. Test sign-up flow manually
5. Deploy to production

