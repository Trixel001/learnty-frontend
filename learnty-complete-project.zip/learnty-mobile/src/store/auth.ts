import { create } from 'zustand'
import { supabase, Profile, UserAchievement } from '@/lib/supabase'
import { User } from '@supabase/supabase-js'

interface AuthState {
  user: User | null
  profile: Profile | null
  achievements: UserAchievement[]
  isLoading: boolean
  hasCompletedOnboarding: boolean
  lastActiveTime: number
  setUser: (user: User | null) => void
  setProfile: (profile: Profile | null) => void
  setAchievements: (achievements: UserAchievement[]) => void
  signUp: (email: string, password: string, fullName: string) => Promise<void>
  signIn: (email: string, password: string) => Promise<void>
  signOut: () => Promise<void>
  loadProfile: () => Promise<void>
  loadAchievements: () => Promise<void>
  completeOnboarding: () => void
  uploadAvatar: (file: File) => Promise<string | null>
  updateProfile: (updates: Partial<Profile>) => Promise<void>
  initializeAuth: () => Promise<void>
  refreshUserData: () => Promise<void>
  handleVisibilityChange: () => Promise<void>
}

export const useAuthStore = create<AuthState>((set, get) => ({
  user: null,
  profile: null,
  achievements: [],
  isLoading: true,
  hasCompletedOnboarding: localStorage.getItem('onboarding_completed') === 'true',
  lastActiveTime: Date.now(),

  setUser: (user) => set({ user }),
  setProfile: (profile) => set({ profile }),
  setAchievements: (achievements) => set({ achievements }),

  signUp: async (email, password, fullName) => {
    set({ isLoading: true })
    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
      })
      
      if (error) throw error
      if (!data.user) throw new Error('No user returned')

      // Create profile directly in database
      const { error: profileError } = await supabase
        .from('profiles')
        .insert({
          id: data.user.id,
          full_name: fullName,
          total_xp: 0,
          level: 1,
          current_streak: 0,
          longest_streak: 0,
          books_read: 0,
          study_minutes: 0,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        })

      if (profileError) {
        console.error('Profile creation error:', profileError)
        throw new Error('Unable to complete registration. Please try again.')
      }

      set({ user: data.user })
    } catch (error: any) {
      // User-friendly error messages
      const message = error.message.includes('already registered') 
        ? 'This email is already registered. Please sign in instead.'
        : error.message.includes('Unable to complete registration')
        ? error.message
        : 'Registration failed. Please try again.'
      throw new Error(message)
    } finally {
      set({ isLoading: false })
    }
  },

  signIn: async (email, password) => {
    set({ isLoading: true })
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      })
      
      if (error) throw error
      if (!data.user) throw new Error('No user returned')

      console.log('[Auth] Sign in successful, user:', data.user.email)
      
      // *** FIX BUG #3: SET USER AND STOP LOADING IMMEDIATELY ***
      set({ user: data.user, isLoading: false, lastActiveTime: Date.now() })
      
      // *** FIX BUG #3: LOAD DATA IN BACKGROUND ***
      get().refreshUserData().catch(error => {
        console.error('[Auth] Background data refresh failed on sign-in:', error)
      })
      
      console.log('[Auth] Sign in complete, data loading in background')
    } catch (error: any) {
      set({ isLoading: false })
      throw new Error(error.message || 'Sign in failed')
    }
  },

  signOut: async () => {
    console.log('[Auth] Signing out...')
    
    // Clear all state first
    set({ 
      user: null, 
      profile: null, 
      achievements: [], 
      isLoading: false 
    })
    
    // Clear onboarding status
    localStorage.removeItem('onboarding_completed')
    set({ hasCompletedOnboarding: false })
    
    // Sign out from Supabase
    await supabase.auth.signOut()
    
    console.log('[Auth] Sign out complete')
  },

  loadProfile: async () => {
    const user = get().user
    if (!user) {
      console.log('[Auth] No user, skipping profile load')
      return
    }

    try {
      console.log('[Auth] Loading profile for user:', user.email)
      
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .maybeSingle()

      if (error) {
        console.error('[Auth] Error loading profile:', error)
        return
      }

      if (data) {
        console.log('[Auth] Profile loaded successfully')
        set({ profile: data })
      } else {
        console.warn('[Auth] No profile found for user')
      }
    } catch (error) {
      console.error('[Auth] Profile loading error:', error)
    }
  },

  loadAchievements: async () => {
    const user = get().user
    if (!user) {
      console.log('[Auth] No user, skipping achievements load')
      return
    }

    try {
      console.log('[Auth] Loading achievements for user:', user.email)
      
      const { data, error } = await supabase
        .from('user_achievements')
        .select('*, achievements(*)')
        .eq('user_id', user.id)
        .order('earned_at', { ascending: false })

      if (error) {
        console.error('[Auth] Error loading achievements:', error)
        return
      }

      console.log('[Auth] Achievements loaded:', data?.length || 0)
      set({ achievements: data || [] })
    } catch (error) {
      console.error('[Auth] Achievements loading error:', error)
    }
  },

  completeOnboarding: () => {
    localStorage.setItem('onboarding_completed', 'true')
    set({ hasCompletedOnboarding: true })
    
    // Award onboarding achievement
    const user = get().user
    if (user) {
      supabase.functions.invoke('award-achievement', {
        body: { userId: user.id, achievementType: 'onboarding' }
      }).catch(console.error)
    }
  },

  uploadAvatar: async (file: File) => {
    const user = get().user
    if (!user) throw new Error('No user logged in')

    // Convert file to base64
    return new Promise((resolve, reject) => {
      const reader = new FileReader()
      reader.onloadend = async () => {
        try {
          const base64Data = reader.result as string
          const { data, error } = await supabase.functions.invoke('upload-avatar', {
            body: {
              imageData: base64Data,
              fileName: `${Date.now()}-${file.name}`,
              userId: user.id
            }
          })

          if (error) throw error
          const url = data?.data?.publicUrl
          if (url) {
            await get().loadProfile()
          }
          resolve(url)
        } catch (err: any) {
          reject(err)
        }
      }
      reader.onerror = reject
      reader.readAsDataURL(file)
    })
  },

  updateProfile: async (updates) => {
    const user = get().user
    if (!user) throw new Error('No user logged in')

    const { error } = await supabase
      .from('profiles')
      .update({
        ...updates,
        updated_at: new Date().toISOString()
      })
      .eq('id', user.id)

    if (error) throw error
    await get().loadProfile()
  },

  initializeAuth: async () => {
    const timeout = setTimeout(() => {
      console.error('[Auth] Initialization timeout after 15s')
      set({ isLoading: false })
    }, 15000)
    
    try {
      console.log('[Auth] Starting initialization...')
      set({ isLoading: true, lastActiveTime: Date.now() })
      
      // Get current session with multiple retries
      let session = null
      let lastError = null
      
      for (let attempt = 1; attempt <= 5; attempt++) {
        console.log(`[Auth] Session attempt ${attempt}/5`)
        
        const { data, error } = await supabase.auth.getSession()
        
        if (!error && data.session) {
          session = data.session
          console.log('[Auth] Session retrieved successfully')
          break
        }
        
        lastError = error
        console.warn(`[Auth] Attempt ${attempt} failed:`, error?.message)
        
        if (attempt < 5) {
          // Exponential backoff: 500ms, 1s, 2s, 4s
          const delay = 500 * Math.pow(2, attempt - 1)
          await new Promise(resolve => setTimeout(resolve, delay))
        }
      }
      
      if (!session) {
        console.log('[Auth] No session found after retries')
        set({ isLoading: false, user: null, profile: null, achievements: [] })
        clearTimeout(timeout)
        return
      }

      console.log('[Auth] Valid session found for:', session.user.email)
      
      // *** FIX: SET USER AND STOP LOADING IMMEDIATELY ***
      set({ user: session.user, isLoading: false, lastActiveTime: Date.now() })
      
      // *** FIX BUG #5: LOAD DATA IN THE BACKGROUND with user feedback ***
      get().refreshUserData().catch(error => {
        console.error('[Auth] Background data refresh failed:', error)
        // Show toast notification so user knows something went wrong
        import('react-hot-toast').then(({ default: toast }) => {
          toast.error('Failed to load profile data. Please refresh the page.')
        })
      })
      
    } catch (error) {
      console.error('[Auth] Initialization error:', error)
      set({ user: null, profile: null, achievements: [], isLoading: false })
    } finally {
      clearTimeout(timeout)
      // We already set isLoading: false, so we just clear the timeout
      console.log('[Auth] Initialization complete')
    }
  },

  refreshUserData: async () => {
    const user = get().user
    if (!user) {
      console.log('[Auth] No user found, skipping data refresh')
      return
    }
    
    try {
      console.log('[Auth] Refreshing user data for:', user.email)
      
      // Load profile and achievements in parallel
      await Promise.all([
        get().loadProfile(),
        get().loadAchievements()
      ])
      
      set({ lastActiveTime: Date.now() })
      console.log('[Auth] User data refresh complete')
    } catch (error) {
      console.error('[Auth] Error refreshing user data:', error)
      throw error
    }
  },

  handleVisibilityChange: async () => {
    if (document.visibilityState === 'visible') {
      const { user, lastActiveTime } = get()
      const now = Date.now()
      const timeSinceLastActive = now - lastActiveTime
      
      console.log('[Auth] App became visible, inactive time:', Math.floor(timeSinceLastActive / 1000), 'seconds')
      
      // If we have a user and it's been more than 10 seconds
      if (user && timeSinceLastActive > 10000) {
        console.log('[Auth] Checking session validity...')
        
        try {
          // Refresh session
          const { data: { session }, error } = await supabase.auth.refreshSession()
          
          if (error) {
            console.error('[Auth] Session refresh failed:', error)
            
            // Try to get current session as fallback
            const { data: { session: currentSession } } = await supabase.auth.getSession()
            
            if (!currentSession) {
              console.log('[Auth] No valid session, signing out')
              set({ user: null, profile: null, achievements: [], isLoading: false })
              return
            }
          }
          
          if (session?.user) {
            console.log('[Auth] Session refreshed, reloading user data')
            set({ user: session.user })
            
            // Reload profile and achievements
            await get().refreshUserData()
          } else {
            console.log('[Auth] Session expired, clearing state')
            set({ user: null, profile: null, achievements: [], isLoading: false })
          }
        } catch (error) {
          console.error('[Auth] Error during visibility change handler:', error)
        }
      }
      
      set({ lastActiveTime: now })
    }
  },
}))

// Initialize auth state on app start
console.log('[Auth] Initializing auth store...')
useAuthStore.getState().initializeAuth()

// Listen to auth changes
supabase.auth.onAuthStateChange(async (event, session) => {
  console.log('[Auth] State change event:', event, 'hasSession:', !!session)
  
  const { setUser, refreshUserData, isLoading } = useAuthStore.getState()
  
  try {
    if (event === 'SIGNED_OUT') {
      console.log('[Auth] User signed out event')
      setUser(null)
      useAuthStore.setState({ 
        profile: null, 
        achievements: [],
        isLoading: false,
        lastActiveTime: Date.now()
      })
    } else if (session?.user) {
      console.log('[Auth] Auth event with user:', session.user.email, 'event:', event)
      setUser(session.user)
      useAuthStore.setState({ lastActiveTime: Date.now() })
      
      // Always reload data for any auth event except TOKEN_REFRESHED
      if (event !== 'TOKEN_REFRESHED' && !isLoading) {
        console.log('[Auth] Reloading user data due to auth event:', event)
        await refreshUserData()
      } else if (event === 'TOKEN_REFRESHED') {
        console.log('[Auth] Token refreshed, checking if data needs reload')
        const { profile } = useAuthStore.getState()
        if (!profile) {
          console.log('[Auth] Profile missing, reloading data')
          await refreshUserData()
        }
      }
    }
  } catch (error) {
    console.error('[Auth] Error handling auth state change:', error)
  }
})

// Handle visibility changes for mobile browsers
if (typeof document !== 'undefined') {
  document.addEventListener('visibilitychange', () => {
    useAuthStore.getState().handleVisibilityChange()
  })

  // Also handle focus events
  window.addEventListener('focus', () => {
    useAuthStore.getState().handleVisibilityChange()
  })
  
  // Handle page unload to update last active time
  window.addEventListener('beforeunload', () => {
    useAuthStore.setState({ lastActiveTime: Date.now() })
  })
}
