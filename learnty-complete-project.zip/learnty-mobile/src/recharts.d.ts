declare module 'recharts' {
  export * from 'recharts/types/index'
}
