import { useState, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuthStore } from '@/store/auth'
import { Camera, Mail, Star, TrendingUp, Flame, LogOut, Loader2, Edit2, X, Settings, User, Bell, Shield, HelpCircle, Moon } from 'lucide-react'
import toast from 'react-hot-toast'

export default function Menu() {
  const { user, profile, signOut, uploadAvatar, updateProfile } = useAuthStore()
  const navigate = useNavigate()
  const [isEditing, setIsEditing] = useState(false)
  const [fullName, setFullName] = useState(profile?.full_name || '')
  const [isUploading, setIsUploading] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleSignOut = async () => {
    await signOut()
    navigate('/auth')
  }

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    if (file.size > 5 * 1024 * 1024) {
      toast.error('Image must be less than 5MB')
      return
    }

    setIsUploading(true)
    try {
      await uploadAvatar(file)
      toast.success('Profile picture updated!')
    } catch (error: any) {
      toast.error(error.message || 'Failed to upload image')
    } finally {
      setIsUploading(false)
    }
  }

  const handleSave = async () => {
    if (!fullName.trim()) {
      toast.error('Name cannot be empty')
      return
    }

    setIsSaving(true)
    try {
      await updateProfile({ full_name: fullName.trim() })
      toast.success('Profile updated!')
      setIsEditing(false)
    } catch (error: any) {
      toast.error(error.message || 'Failed to update profile')
    } finally {
      setIsSaving(false)
    }
  }

  const stats = [
    {
      icon: Star,
      label: 'Total XP',
      value: profile?.total_xp || 0,
      color: 'from-blue-500 to-purple-500'
    },
    {
      icon: TrendingUp,
      label: 'Current Level',
      value: profile?.level || 1,
      color: 'from-green-500 to-emerald-500'
    },
    {
      icon: Flame,
      label: 'Learning Streak',
      value: `${profile?.streak_count || 0} days`,
      color: 'from-orange-500 to-red-500'
    }
  ]

  const menuItems = [
    {
      icon: User,
      label: 'Edit Profile',
      description: 'Update your personal information',
      action: () => setIsEditing(!isEditing)
    },
    {
      icon: Settings,
      label: 'Settings',
      description: 'App preferences and configurations',
      action: () => navigate('/settings')
    },
    {
      icon: Bell,
      label: 'Notifications',
      description: 'Manage your notification preferences',
      action: () => navigate('/notifications')
    },
    {
      icon: Shield,
      label: 'Privacy & Security',
      description: 'Manage your privacy settings',
      action: () => navigate('/privacy')
    },
    {
      icon: HelpCircle,
      label: 'Help & Support',
      description: 'Get help or contact support',
      action: () => navigate('/help')
    }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 pb-24">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 px-6 pt-12 pb-32 rounded-b-3xl shadow-lg">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-2xl font-bold text-white">Menu</h1>
          <button
            onClick={() => navigate('/dashboard')}
            className="p-2 bg-white/20 rounded-lg text-white hover:bg-white/30 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Avatar and Profile Info */}
      <div className="px-6 -mt-24 mb-6">
        <div className="bg-white rounded-2xl p-6 shadow-lg">
          <div className="flex flex-col items-center mb-6">
            <div className="relative mb-4">
              <div className="w-32 h-32 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center overflow-hidden">
                {isUploading ? (
                  <Loader2 className="w-12 h-12 text-white animate-spin" />
                ) : profile?.avatar_url ? (
                  <img src={profile.avatar_url} alt="Avatar" className="w-full h-full object-cover" />
                ) : (
                  <div className="text-white text-4xl font-bold">
                    {profile?.full_name?.charAt(0) || 'U'}
                  </div>
                )}
              </div>
              <button
                onClick={() => fileInputRef.current?.click()}
                className="absolute bottom-0 right-0 w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center shadow-lg hover:bg-blue-700 transition-colors"
              >
                <Camera className="w-5 h-5 text-white" />
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleAvatarUpload}
                className="hidden"
              />
            </div>

            {isEditing ? (
              <div className="w-full space-y-3">
                <input
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                  placeholder="Full Name"
                />
                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      setIsEditing(false)
                      setFullName(profile?.full_name || '')
                    }}
                    className="flex-1 px-4 py-3 bg-gray-200 text-gray-700 rounded-xl font-medium hover:bg-gray-300 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleSave}
                    disabled={isSaving}
                    className="flex-1 px-4 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl font-medium shadow-lg hover:shadow-xl transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {isSaving ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        Saving...
                      </>
                    ) : (
                      'Save'
                    )}
                  </button>
                </div>
              </div>
            ) : (
              <>
                <h2 className="text-2xl font-bold text-gray-900 mb-1">
                  {profile?.full_name || 'User'}
                </h2>
                <div className="flex items-center gap-2 text-gray-600">
                  <Mail className="w-4 h-4" />
                  <span className="text-sm">{user?.email}</span>
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="px-6 mb-6">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Learning Stats</h3>
        <div className="space-y-3">
          {stats.map((stat) => {
            const Icon = stat.icon
            return (
              <div key={stat.label} className="bg-white rounded-2xl p-4 shadow-lg flex items-center gap-4">
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center flex-shrink-0`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <p className="text-sm text-gray-600">{stat.label}</p>
                  <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                </div>
              </div>
            )
          })}
        </div>
      </div>

      {/* Menu Items */}
      <div className="px-6 mb-6">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Menu</h3>
        <div className="space-y-3">
          {menuItems.map((item) => {
            const Icon = item.icon
            return (
              <button
                key={item.label}
                onClick={item.action}
                className="w-full bg-white rounded-2xl p-4 shadow-lg text-left hover:shadow-xl transition-all flex items-center gap-4"
              >
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center flex-shrink-0">
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <p className="font-semibold text-gray-900">{item.label}</p>
                  <p className="text-sm text-gray-600">{item.description}</p>
                </div>
              </button>
            )
          })}
        </div>
      </div>

      {/* Dark Mode Toggle */}
      <div className="px-6 mb-6">
        <div className="bg-white rounded-2xl p-4 shadow-lg flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-gray-600 to-gray-800 flex items-center justify-center">
              <Moon className="w-6 h-6 text-white" />
            </div>
            <div>
              <p className="font-semibold text-gray-900">Dark Mode</p>
              <p className="text-sm text-gray-600">Toggle theme preference</p>
            </div>
          </div>
          <div className="relative">
            <input type="checkbox" className="sr-only" />
            <div className="w-11 h-6 bg-gray-300 rounded-full shadow-inner"></div>
            <div className="absolute w-5 h-5 bg-white rounded-full shadow -left-1 -top-0.5"></div>
          </div>
        </div>
      </div>

      {/* Sign Out */}
      <div className="px-6 pb-8">
        <button
          onClick={handleSignOut}
          className="w-full bg-white border-2 border-red-500 text-red-500 py-4 rounded-xl font-semibold shadow-lg hover:bg-red-50 transition-all flex items-center justify-center gap-2 active:scale-95"
        >
          <LogOut className="w-5 h-5" />
          Sign Out
        </button>
      </div>
    </div>
  )
}