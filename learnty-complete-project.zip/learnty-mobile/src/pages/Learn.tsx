import { useState } from 'react'
import { motion } from 'framer-motion'
import { useNavigate } from 'react-router-dom'
import { Brain, MapPin, RotateCcw, Plus } from 'lucide-react'

export default function Learn() {
  const [activeTab, setActiveTab] = useState('paths')
  const navigate = useNavigate()

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 pb-24">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 px-6 pt-12 pb-4">
        <h1 className="text-2xl font-bold text-white mb-4">Learn</h1>
        
        {/* Tab Navigation */}
        <div className="flex gap-4">
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => setActiveTab('paths')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl transition-all ${
              activeTab === 'paths' 
                ? 'bg-white/20 text-white font-semibold' 
                : 'text-white/70 hover:text-white'
            }`}
          >
            <MapPin className="w-4 h-4" />
            <span>Learning Paths</span>
          </motion.button>
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => setActiveTab('review')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl transition-all ${
              activeTab === 'review' 
                ? 'bg-white/20 text-white font-semibold' 
                : 'text-white/70 hover:text-white'
            }`}
          >
            <RotateCcw className="w-4 h-4" />
            <span>Review Cards</span>
          </motion.button>
        </div>
      </div>

      {/* Tab Content */}
      <div className="px-6 pt-6">
        {activeTab === 'paths' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-lg font-semibold text-gray-900">Your Learning Paths</h2>
              <motion.button
                whileTap={{ scale: 0.95 }}
                onClick={() => navigate('/learning-paths?action=create')}
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-xl font-medium"
              >
                <Plus className="w-4 h-4" />
                New Path
              </motion.button>
            </div>
            {/* Learning Paths content will go here */}
            <div className="text-center py-8 text-gray-500">
              <MapPin className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>Learning Paths will be displayed here</p>
              <p className="text-sm">Create your first path using the button above</p>
            </div>
          </div>
        )}
        
        {activeTab === 'review' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-lg font-semibold text-gray-900">Review Cards</h2>
              <motion.button
                whileTap={{ scale: 0.95 }}
                onClick={() => navigate('/review?mode=quick')}
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-xl font-medium"
              >
                <Brain className="w-4 h-4" />
                Start Review
              </motion.button>
            </div>
            {/* Review content will go here */}
            <div className="text-center py-8 text-gray-500">
              <RotateCcw className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>Review Cards will be displayed here</p>
              <p className="text-sm">Start a review session using the button above</p>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}