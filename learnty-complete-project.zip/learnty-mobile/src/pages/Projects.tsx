import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { useNavigate } from 'react-router-dom'
import { useAuthStore } from '@/store/auth'
import { supabase } from '@/lib/supabase'
import toast from 'react-hot-toast'
import { 
  FolderOpen, 
  Plus, 
  Play, 
  Pause, 
  CheckCircle, 
  Clock, 
  BookOpen,
  Target,
  Calendar,
  TrendingUp,
  ArrowRight,
  Search,
  Filter,
  MoreHorizontal
} from 'lucide-react'
import TopicLearningGenerator from '@/components/TopicLearningGenerator'

interface Project {
  id: string
  title: string
  description?: string
  topic?: string
  detail_level: 'beginner' | 'intermediate' | 'advanced'
  estimated_hours: number
  status: 'active' | 'completed' | 'paused'
  created_at: string
  updated_at: string
  progress?: number
  milestones_completed?: number
  total_milestones?: number
}

interface Milestone {
  id: string
  title: string
  description?: string
  project_id: string
  order_index: number
  status: 'pending' | 'in_progress' | 'completed'
  due_date?: string
  completed_at?: string
}

export default function Projects() {
  const { user } = useAuthStore()
  const navigate = useNavigate()
  const [projects, setProjects] = useState<Project[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'completed' | 'paused'>('all')
  const [showTopicGenerator, setShowTopicGenerator] = useState(false)

  useEffect(() => {
    if (user?.id) {
      loadProjects()
    }
  }, [user?.id])

  const loadProjects = async () => {
    if (!user?.id) return

    try {
      setIsLoading(true)
      
      // Load projects from Supabase
      const { data: projectsData, error: projectsError } = await supabase
        .from('projects')
        .select(`
          *,
          project_milestones(count)
        `)
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })

      if (projectsError) {
        console.error('Error loading projects:', projectsError)
        toast.error('Failed to load projects')
        return
      }

      // Load milestones for each project
      const projectsWithMilestones = await Promise.all(
        (projectsData || []).map(async (project) => {
          const { data: milestones, error: milestonesError } = await supabase
            .from('project_milestones')
            .select('*')
            .eq('project_id', project.id)
            .order('order_index')

          if (milestonesError) {
            console.error('Error loading milestones for project:', project.id, milestonesError)
          }

          const completedMilestones = milestones?.filter(m => m.status === 'completed').length || 0
          const totalMilestones = milestones?.length || 0
          const progress = totalMilestones > 0 ? (completedMilestones / totalMilestones) * 100 : 0

          return {
            ...project,
            milestones_completed: completedMilestones,
            total_milestones: totalMilestones,
            progress
          }
        })
      )

      setProjects(projectsWithMilestones)
    } catch (error) {
      console.error('Error loading projects:', error)
      toast.error('Failed to load projects')
    } finally {
      setIsLoading(false)
    }
  }

  const filteredProjects = projects.filter(project => {
    const matchesSearch = project.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         project.topic?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         project.description?.toLowerCase().includes(searchTerm.toLowerCase())
    
    const matchesFilter = filterStatus === 'all' || project.status === filterStatus
    
    return matchesSearch && matchesFilter
  })

  const activeProjects = filteredProjects.filter(p => p.status === 'active')
  const completedProjects = filteredProjects.filter(p => p.status === 'completed')
  const pausedProjects = filteredProjects.filter(p => p.status === 'paused')

  const getStatusIcon = (status: Project['status']) => {
    switch (status) {
      case 'active':
        return <Play className="w-4 h-4 text-green-600" />
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-blue-600" />
      case 'paused':
        return <Pause className="w-4 h-4 text-orange-600" />
      default:
        return <Clock className="w-4 h-4 text-gray-600" />
    }
  }

  const getStatusColor = (status: Project['status']) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-700 border-green-200'
      case 'completed':
        return 'bg-blue-100 text-blue-700 border-blue-200'
      case 'paused':
        return 'bg-orange-100 text-orange-700 border-orange-200'
      default:
        return 'bg-gray-100 text-gray-700 border-gray-200'
    }
  }

  const handleProjectClick = (project: Project) => {
    // Navigate to project details or continue working on it
    toast.success(`Opening project: ${project.title}`)
    // In a real implementation, this would navigate to a project detail page
  }

  const handleCreateProject = () => {
    setShowTopicGenerator(true)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 pb-24">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 px-4 sm:px-6 pt-8 sm:pt-12 pb-6">
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-3 sm:gap-4 mb-6"
        >
          <div className="w-12 h-12 sm:w-16 sm:h-16 rounded-full bg-white/20 flex items-center justify-center">
            <FolderOpen className="w-6 h-6 sm:w-8 sm:h-8 text-white" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-white">My Projects</h1>
            <p className="text-white/80 text-sm sm:text-base">
              {projects.length} project{projects.length !== 1 ? 's' : ''} created
            </p>
          </div>
        </motion.div>

        {/* Quick Stats */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="grid grid-cols-3 gap-3 sm:gap-4"
        >
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-3 sm:p-4">
            <div className="text-lg sm:text-2xl font-bold text-white">{activeProjects.length}</div>
            <div className="text-white/80 text-xs sm:text-sm">Active</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-3 sm:p-4">
            <div className="text-lg sm:text-2xl font-bold text-white">{completedProjects.length}</div>
            <div className="text-white/80 text-xs sm:text-sm">Completed</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-3 sm:p-4">
            <div className="text-lg sm:text-2xl font-bold text-white">{pausedProjects.length}</div>
            <div className="text-white/80 text-xs sm:text-sm">Paused</div>
          </div>
        </motion.div>
      </div>

      <div className="px-4 sm:px-6 -mt-4">
        {/* Search and Filter */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white rounded-2xl p-4 sm:p-6 shadow-lg mb-6"
        >
          <div className="flex flex-col sm:flex-row gap-3 sm:gap-4">
            {/* Search */}
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search projects..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none transition-colors text-sm sm:text-base"
              />
            </div>

            {/* Filter */}
            <div className="relative">
              <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value as any)}
                className="pl-10 pr-8 py-2.5 border border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none transition-colors text-sm sm:text-base bg-white min-w-[120px]"
              >
                <option value="all">All Status</option>
                <option value="active">Active</option>
                <option value="completed">Completed</option>
                <option value="paused">Paused</option>
              </select>
            </div>

            {/* Create New Project Button */}
            <button
              onClick={handleCreateProject}
              className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-4 sm:px-6 py-2.5 rounded-xl font-medium hover:opacity-90 transition-all flex items-center gap-2 whitespace-nowrap text-sm sm:text-base"
            >
              <Plus className="w-4 h-4" />
              New Project
            </button>
          </div>
        </motion.div>

        {/* Projects List */}
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          </div>
        ) : filteredProjects.length === 0 ? (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center py-12"
          >
            <FolderOpen className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              {searchTerm || filterStatus !== 'all' ? 'No projects found' : 'No projects yet'}
            </h3>
            <p className="text-gray-600 mb-6">
              {searchTerm || filterStatus !== 'all' 
                ? 'Try adjusting your search or filter criteria'
                : 'Create your first learning project to get started'
              }
            </p>
            {!searchTerm && filterStatus === 'all' && (
              <button
                onClick={handleCreateProject}
                className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-6 py-3 rounded-xl font-medium hover:opacity-90 transition-all flex items-center gap-2 mx-auto"
              >
                <Plus className="w-5 h-5" />
                Create Your First Project
              </button>
            )}
          </motion.div>
        ) : (
          <div className="space-y-4">
            {['Active Projects', 'Completed Projects', 'Paused Projects'].map((category) => {
              const categoryProjects = category === 'Active Projects' ? activeProjects 
                                      : category === 'Completed Projects' ? completedProjects 
                                      : pausedProjects
              
              if (categoryProjects.length === 0) return null

              return (
                <div key={category} className="mb-6">
                  <h2 className="text-lg font-bold text-gray-900 mb-3">{category}</h2>
                  <div className="space-y-3">
                    {categoryProjects.map((project, index) => (
                      <motion.div
                        key={project.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.1 }}
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        onClick={() => handleProjectClick(project)}
                        className="bg-white rounded-2xl p-4 sm:p-6 shadow-lg hover:shadow-xl transition-all cursor-pointer"
                      >
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              {getStatusIcon(project.status)}
                              <h3 className="font-semibold text-gray-900 text-base sm:text-lg">{project.title}</h3>
                            </div>
                            {project.topic && (
                              <div className="flex items-center gap-2 mb-2">
                                <BookOpen className="w-4 h-4 text-gray-400" />
                                <span className="text-sm text-gray-600">{project.topic}</span>
                              </div>
                            )}
                            {project.description && (
                              <p className="text-sm text-gray-600 mb-3 line-clamp-2">{project.description}</p>
                            )}
                          </div>
                          <div className="flex items-center gap-2">
                            <span className={`px-3 py-1 rounded-full text-xs font-medium border ${getStatusColor(project.status)}`}>
                              {project.status}
                            </span>
                            <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                              <MoreHorizontal className="w-4 h-4 text-gray-400" />
                            </button>
                          </div>
                        </div>

                        {/* Progress */}
                        {project.status === 'active' && project.total_milestones && (
                          <div className="mb-3">
                            <div className="flex items-center justify-between text-sm text-gray-600 mb-1">
                              <span>Progress</span>
                              <span>{Math.round(project.progress || 0)}%</span>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-2">
                              <motion.div
                                initial={{ width: 0 }}
                                animate={{ width: `${project.progress || 0}%` }}
                                transition={{ duration: 1, delay: 0.5 }}
                                className="bg-gradient-to-r from-blue-500 to-purple-600 h-2 rounded-full"
                              />
                            </div>
                          </div>
                        )}

                        <div className="flex items-center justify-between text-xs text-gray-500">
                          <div className="flex items-center gap-4">
                            <div className="flex items-center gap-1">
                              <Target className="w-3 h-3" />
                              <span>{project.detail_level}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              <span>{project.estimated_hours}h</span>
                            </div>
                            {project.milestones_completed !== undefined && project.total_milestones && (
                              <div className="flex items-center gap-1">
                                <TrendingUp className="w-3 h-3" />
                                <span>{project.milestones_completed}/{project.total_milestones} milestones</span>
                              </div>
                            )}
                          </div>
                          <ArrowRight className="w-4 h-4 text-gray-400" />
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </div>

      {/* Topic Learning Generator Modal */}
      <TopicLearningGenerator 
        isOpen={showTopicGenerator}
        onSuccess={() => {
          setShowTopicGenerator(false)
          loadProjects()
          toast.success('Project created successfully!')
        }}
        onClose={() => setShowTopicGenerator(false)}
      />
    </div>
  )
}
