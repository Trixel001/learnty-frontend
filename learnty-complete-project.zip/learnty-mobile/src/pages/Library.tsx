import { useState } from 'react'
import { motion } from 'framer-motion'
import { useNavigate } from 'react-router-dom'
import { BookOpen, FolderOpen, Search, Plus, Brain } from 'lucide-react'
import BookUpload from '@/components/BookUpload'
import Projects from './Projects'
import LearningPaths from './LearningPaths'
import toast from 'react-hot-toast'

export default function Library() {
  const [activeTab, setActiveTab] = useState('books')
  const navigate = useNavigate()

  const tabs = [
    { 
      key: 'books', 
      icon: BookOpen, 
      label: 'My Books',
      description: 'Uploaded books for gamification'
    },
    { 
      key: 'topics', 
      icon: Brain, 
      label: 'My Topics',
      description: 'AI-powered learning paths'
    },
    { 
      key: 'projects', 
      icon: FolderOpen, 
      label: 'My Projects',
      description: 'Your learning projects'
    }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 pb-24">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 px-6 pt-12 pb-4">
        <h1 className="text-2xl font-bold text-white mb-4">Library</h1>
        <p className="text-white/80 text-sm mb-6">Your personal content collection</p>
        
        {/* Tab Navigation */}
        <div className="flex gap-2 overflow-x-auto">
          {tabs.map((tab) => {
            const Icon = tab.icon
            return (
              <motion.button
                key={tab.key}
                whileTap={{ scale: 0.95 }}
                onClick={() => setActiveTab(tab.key)}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl transition-all whitespace-nowrap ${
                  activeTab === tab.key 
                    ? 'bg-white/20 text-white font-semibold' 
                    : 'text-white/70 hover:text-white hover:bg-white/10'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span className="text-sm">{tab.label}</span>
              </motion.button>
            )
          })}
        </div>
      </div>

      {/* Tab Content */}
      <div className="px-6 pt-6">
        {activeTab === 'books' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-lg font-semibold text-gray-900">My Books</h2>
                <p className="text-sm text-gray-600">Books you've uploaded for gamified learning</p>
              </div>
              <motion.button
                whileTap={{ scale: 0.95 }}
                onClick={() => navigate('/books?action=add')}
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-xl font-medium"
              >
                <Plus className="w-4 h-4" />
                Upload Book
              </motion.button>
            </div>
            <BookUpload onUploadSuccess={() => {
              toast.success('Book added to your library!')
            }} />
          </div>
        )}

        {activeTab === 'topics' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-lg font-semibold text-gray-900">My Topics</h2>
                <p className="text-sm text-gray-600">AI-generated learning paths from topics</p>
              </div>
              <motion.button
                whileTap={{ scale: 0.95 }}
                onClick={() => navigate('/learning-paths?action=create')}
                className="flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-xl font-medium"
              >
                <Plus className="w-4 h-4" />
                Create Path
              </motion.button>
            </div>
            <LearningPaths />
          </div>
        )}
        
        {activeTab === 'projects' && <Projects />}
      </div>
    </div>
  )
}