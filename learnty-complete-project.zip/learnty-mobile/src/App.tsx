// Enhanced error logging
console.log('App.tsx loaded')

import React from 'react'
import { BrowserRouter, Routes, Route, Navigate, useLocation, useNavigate } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import { motion } from 'framer-motion'
import { useAuthStore } from './store/auth'
import Onboarding from './pages/Onboarding'
import Auth from './pages/Auth'
import PendingConfirmation from './pages/PendingConfirmation'
import Dashboard from './pages/Dashboard'
import Profile from './pages/Profile'
import { ErrorBoundary } from './components/ErrorBoundary'
import BookLoader from './components/BookLoader'
import { LayoutDashboard, BookOpen, MapPin, User, RotateCcw, Timer, FolderOpen, Brain } from 'lucide-react'

// Lazy load Books, LearningPaths, and Review with error boundaries
const Books = React.lazy(() => 
  import('./pages/Books').catch(err => {
    console.error('Failed to load Books component:', err)
    return { default: () => <div className="p-4 text-red-600">Failed to load Books component: {err.message}</div> }
  })
)

const LearningPaths = React.lazy(() => 
  import('./pages/LearningPaths').catch(err => {
    console.error('Failed to load LearningPaths component:', err)
    return { default: () => <div className="p-4 text-red-600">Failed to load LearningPaths component: {err.message}</div> }
  })
)

const Review = React.lazy(() => 
  import('./pages/Review').catch(err => {
    console.error('Failed to load Review component:', err)
    return { default: () => <div className="p-4 text-red-600">Failed to load Review component: {err.message}</div> }
  })
)

const Focus = React.lazy(() => 
  import('./pages/Focus').catch(err => {
    console.error('Failed to load Focus component:', err)
    return { default: () => <div className="p-4 text-red-600">Failed to load Focus component: {err.message}</div> }
  })
)

const FocusAnalytics = React.lazy(() => 
  import('./pages/FocusAnalytics').catch(err => {
    console.error('Failed to load FocusAnalytics component:', err)
    return { default: () => <div className="p-4 text-red-600">Failed to load FocusAnalytics component: {err.message}</div> }
  })
)

const Menu = React.lazy(() => 
  import('./pages/Menu').catch(err => {
    console.error('Failed to load Menu component:', err)
    return { default: () => <div className="p-4 text-red-600">Failed to load Menu component: {err.message}</div> }
  })
)

const Projects = React.lazy(() => 
  import('./pages/Projects').catch(err => {
    console.error('Failed to load Projects component:', err)
    return { default: () => <div className="p-4 text-red-600">Failed to load Projects component: {err.message}</div> }
  })
)

const Library = React.lazy(() => 
  import('./pages/Library').catch(err => {
    console.error('Failed to load Library component:', err)
    return { default: () => <div className="p-4 text-red-600">Failed to load Library component: {err.message}</div> }
  })
)

const Learn = React.lazy(() => 
  import('./pages/Learn').catch(err => {
    console.error('Failed to load Learn component:', err)
    return { default: () => <div className="p-4 text-red-600">Failed to load Learn component: {err.message}</div> }
  })
)

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user, hasCompletedOnboarding, isLoading } = useAuthStore()

  console.log('ProtectedRoute check:', { user: !!user, hasCompletedOnboarding, isLoading })

  // Show loading while auth is being checked
  if (isLoading) {
    return <BookLoader fullscreen />
  }

  // Check onboarding status first
  if (!hasCompletedOnboarding) {
    console.log('Redirecting to onboarding - not completed')
    return <Navigate to="/onboarding" replace />
  }

  // Then check user authentication
  if (!user) {
    console.log('Redirecting to auth - no user')
    return <Navigate to="/auth" replace />
  }

  console.log('ProtectedRoute - access granted')
  return <>{children}</>
}

function BottomNav() {
  const location = useLocation()
  const navigate = useNavigate()

  const navItems = [
    { path: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
    { path: '/library', icon: BookOpen, label: 'Library' },
    { path: '/learn', icon: Brain, label: 'Learn' },
    { path: '/focus', icon: Timer, label: 'Focus' },
    { path: '/profile', icon: User, label: 'Profile' }
  ]

  const showNav = navItems.some(item => location.pathname.startsWith(item.path)) || 
                  location.pathname.startsWith('/focus/analytics')
  if (!showNav) return null

  return (
    <motion.div 
      initial={{ y: 100 }}
      animate={{ y: 0 }}
      transition={{ type: "spring", stiffness: 300, damping: 30 }}
      className="fixed bottom-0 left-0 right-0 bg-white/80 backdrop-blur-xl border-t border-gray-200 px-1 sm:px-2 py-1 sm:py-2 safe-area-bottom z-50 shadow-lg"
    >
      <div className="flex justify-around items-center max-w-lg mx-auto">
        {navItems.map((item) => {
          const Icon = item.icon
          const isActive = location.pathname.startsWith(item.path)
          
          return (
            <motion.button
              key={item.path}
              onClick={() => navigate(item.path)}
              whileTap={{ scale: 0.95 }}
              className="relative flex flex-col items-center gap-0.5 sm:gap-1 px-2 sm:px-3 py-1.5 sm:py-2 rounded-xl transition-all"
            >
              {isActive && (
                <motion.div
                  layoutId="activeTab"
                  className="absolute inset-0 bg-gradient-to-r from-blue-500/10 to-purple-500/10 rounded-xl"
                  transition={{ type: "spring", stiffness: 380, damping: 30 }}
                />
              )}
              <motion.div
                animate={{
                  scale: isActive ? 1.1 : 1,
                  y: isActive ? -2 : 0
                }}
                transition={{ type: "spring", stiffness: 400, damping: 17 }}
              >
                <Icon 
                  className={`w-5 h-5 sm:w-6 sm:h-6 transition-colors ${
                    isActive ? 'text-blue-600' : 'text-gray-500'
                  }`} 
                />
              </motion.div>
              <span className={`text-xs font-medium transition-colors ${
                isActive ? 'text-blue-600' : 'text-gray-500'
              }`}>
                {item.label}
              </span>
              {isActive && (
                <motion.div
                  layoutId="activeIndicator"
                  className="absolute -bottom-1 w-1 h-1 bg-blue-600 rounded-full"
                  transition={{ type: "spring", stiffness: 380, damping: 30 }}
                />
              )}
            </motion.button>
          )
        })}
      </div>
    </motion.div>
  )
}

function ComingSoon({ title, week }: { title: string; week: string }) {
  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex flex-col items-center justify-center p-6"
    >
      <motion.div 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="text-center"
      >
        <motion.div 
          animate={{ 
            rotate: [0, 10, -10, 0],
            scale: [1, 1.1, 1]
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            repeatDelay: 1
          }}
          className="w-24 h-24 bg-gradient-to-br from-blue-500 to-purple-500 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-lg"
        >
          <span className="text-4xl">🚀</span>
        </motion.div>
        <h1 className="text-3xl font-bold text-gray-900 mb-4">{title}</h1>
        <p className="text-lg text-gray-600 mb-2">Coming in {week}</p>
        <p className="text-gray-500">This feature is under development</p>
      </motion.div>
    </motion.div>
  )
}

function AppContent() {
  const { user, hasCompletedOnboarding, isLoading } = useAuthStore()
  const location = useLocation()

  console.log('AppContent render:', { user: !!user, hasCompletedOnboarding, isLoading, pathname: location.pathname })

  // Show loading spinner while auth is initializing
  if (isLoading) {
    return <BookLoader fullscreen />
  }

  // Add padding bottom for bottom nav on protected routes
  const needsPadding = user && hasCompletedOnboarding && 
    ['/dashboard', '/books', '/learning-paths', '/projects', '/review', '/profile', '/menu', '/library', '/learn', '/focus'].some(path => location.pathname.startsWith(path))

  return (
    <div className={needsPadding ? 'pb-20' : ''}>
      <Routes>
        <Route path="/onboarding" element={
          !hasCompletedOnboarding ? <Onboarding /> : <Navigate to="/auth" replace />
        } />
        <Route path="/auth" element={
          !user ? <Auth /> : <Navigate to="/dashboard" replace />
        } />
        <Route path="/pending-confirmation" element={<PendingConfirmation />} />
        <Route path="/dashboard" element={
          <ProtectedRoute>
            <Dashboard />
          </ProtectedRoute>
        } />
        <Route path="/profile" element={
          <ProtectedRoute>
            <Profile />
          </ProtectedRoute>
        } />
        <Route path="/books" element={
          <ProtectedRoute>
            <ErrorBoundary>
              <React.Suspense fallback={
                <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center">
                  <BookLoader />
                </div>
              }>
                <Books />
              </React.Suspense>
            </ErrorBoundary>
          </ProtectedRoute>
        } />
        <Route path="/learning-paths" element={
          <ProtectedRoute>
            <ErrorBoundary>
              <React.Suspense fallback={
                <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center">
                  <BookLoader />
                </div>
              }>
                <LearningPaths />
              </React.Suspense>
            </ErrorBoundary>
          </ProtectedRoute>
        } />
        <Route path="/projects" element={
          <ProtectedRoute>
            <ErrorBoundary>
              <React.Suspense fallback={
                <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center">
                  <BookLoader />
                </div>
              }>
                <Projects />
              </React.Suspense>
            </ErrorBoundary>
          </ProtectedRoute>
        } />
        <Route path="/menu" element={
          <ProtectedRoute>
            <ErrorBoundary>
              <React.Suspense fallback={
                <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center">
                  <BookLoader />
                </div>
              }>
                <Menu />
              </React.Suspense>
            </ErrorBoundary>
          </ProtectedRoute>
        } />
        <Route path="/library" element={
          <ProtectedRoute>
            <ErrorBoundary>
              <React.Suspense fallback={
                <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center">
                  <BookLoader />
                </div>
              }>
                <Library />
              </React.Suspense>
            </ErrorBoundary>
          </ProtectedRoute>
        } />
        <Route path="/learn" element={
          <ProtectedRoute>
            <ErrorBoundary>
              <React.Suspense fallback={
                <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center">
                  <BookLoader />
                </div>
              }>
                <Learn />
              </React.Suspense>
            </ErrorBoundary>
          </ProtectedRoute>
        } />
        <Route path="/review" element={
          <ProtectedRoute>
            <ErrorBoundary>
              <React.Suspense fallback={
                <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center">
                  <BookLoader />
                </div>
              }>
                <Review />
              </React.Suspense>
            </ErrorBoundary>
          </ProtectedRoute>
        } />
        <Route path="/focus" element={
          <ProtectedRoute>
            <ErrorBoundary>
              <React.Suspense fallback={
                <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center">
                  <BookLoader />
                </div>
              }>
                <Focus />
              </React.Suspense>
            </ErrorBoundary>
          </ProtectedRoute>
        } />
        <Route path="/focus/analytics" element={
          <ProtectedRoute>
            <ErrorBoundary>
              <React.Suspense fallback={
                <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center">
                  <BookLoader />
                </div>
              }>
                <FocusAnalytics />
              </React.Suspense>
            </ErrorBoundary>
          </ProtectedRoute>
        } />
        <Route path="/" element={
          <Navigate to={
            !hasCompletedOnboarding ? "/onboarding" :
            !user ? "/auth" : "/dashboard"
          } replace />
        } />
      </Routes>
      <BottomNav />
    </div>
  )
}

export default function App() {
  console.log('App component render')
  
  return (
    <ErrorBoundary>
      <BrowserRouter>
        <AppContent />
        <Toaster 
          position="top-center"
          toastOptions={{
            duration: 3000,
            style: {
              background: '#363636',
              color: '#fff',
              borderRadius: '12px',
            },
          }}
        />
      </BrowserRouter>
    </ErrorBoundary>
  )
}