# Learnty Mobile - Debugging Guide (v5)

## 📦 Package Contents

This zip contains the complete Learnty learning platform codebase including:

### Frontend Application (`learnty-mobile/`)
- **Framework**: React + TypeScript + Vite
- **Styling**: Tailwind CSS
- **State Management**: Zustand
- **UI Components**: Custom components with shadcn/ui
- **Key Features**: Book upload, AI flashcards, focus timer, spaced repetition

### Backend (`supabase/`)
- **Edge Functions**: Deno-based serverless functions
- **Database Migrations**: SQL schema definitions
- **Table Definitions**: Database structure

## 🚀 Quick Setup

### Prerequisites
- Node.js 18+ or Bun
- pnpm (recommended) or npm
- Supabase CLI (for edge functions)

### Frontend Setup
```bash
cd learnty-mobile
pnpm install
pnpm dev
```

### Environment Variables
Create `learnty-mobile/.env` with:
```
VITE_SUPABASE_URL=https://uqfklmsgerwlrymvfrdy.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVxZmtsbXNnZXJ3bHJ5bXZmcmR5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjE3OTcwNjIsImV4cCI6MjA3NzM3MzA2Mn0.dxwP7rVc-Bm6MPJpjXYDYNlt_-QBeS1Jox3WZttujK0
```

## 🐛 Debugging Book Upload Issue

### Current Status (v5)
**Architecture**: Direct Supabase Storage Upload (redesigned from edge function approach)

### Key Files to Check:
1. **`src/components/BookUpload.tsx`** - Main upload component
   - Direct `supabase.storage.upload()` implementation
   - Progress tracking with callbacks
   - No base64 conversion (streaming upload)

2. **`supabase/functions/process-book-ai-openrouter/index.ts`** - AI processing
   - OpenRouter API integration
   - DeepSeek Chat V3.1 model
   - Timeout: 90 seconds per API call, 3 retries

3. **`src/lib/supabase.ts`** - Supabase client configuration

### Previous Issues (Fixed in v5):
- ❌ v1-v4: Edge function + base64 conversion (caused 30-40% hangs)
- ✅ v5: Direct storage upload (current implementation)

### Testing Book Upload:
```javascript
// In browser console at https://9fzt43ugiuwz.space.minimax.io
// Monitor upload progress:
console.log('Upload started');
// Watch Network tab for:
// - POST to /storage/v1/object/learnty-storage/books/...
// - POST to /functions/v1/process-book-ai-openrouter
```

### Common Issues:
1. **Upload hangs at X%**: Check browser console for errors
2. **Timeout errors**: Verify edge functions are deployed
3. **AI processing fails**: Check OpenRouter API key and quota
4. **Storage errors**: Verify RLS policies on `learnty-storage` bucket

### Edge Functions Endpoints:
- Upload: ~~`/functions/v1/upload-book`~~ (Not used in v5)
- AI Processing: `/functions/v1/process-book-ai-openrouter`
- Flashcards: `/functions/v1/generate-ai-flashcards`
- Quiz: `/functions/v1/generate-ai-quiz`
- Chatbot: `/functions/v1/ai-chatbot`

## 📊 Database Schema

### Key Tables:
- `books` - Book metadata and AI analysis results
- `book_chapters` - AI-generated chapter summaries
- `srs_cards` - Spaced repetition flashcards
- `focus_sessions` - Focus timer tracking
- `profiles` - User profiles
- `achievements` - Gamification achievements
- `learning_sessions` - Study session tracking

## 🔑 API Keys (Hardcoded in Edge Functions)
- **OpenRouter**: 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
- **Model**: deepseek/deepseek-chat-v3.1:free
- **Supabase Service Role**: (Check edge function files)

## 📝 Build & Deploy

### Build Frontend:
```bash
cd learnty-mobile
pnpm build
# Output: dist/ directory
```

### Deploy Edge Functions:
```bash
cd supabase/functions
supabase functions deploy <function-name>
```

### Current Deployment:
- URL: https://9fzt43ugiuwz.space.minimax.io
- Version: v5 (Direct Storage Upload)
- Status: Awaiting user testing

## 🔍 Debugging Tips

1. **Check Browser Console**: Look for React errors and network failures
2. **Check Network Tab**: Monitor API calls and response times
3. **Check Supabase Logs**: View edge function logs in Supabase dashboard
4. **Check Storage**: Verify files appear in `learnty-storage` bucket
5. **Check Database**: Verify records in `books` table with correct `processing_status`

## 📞 Support
For issues, check:
- BUGFIXES_APPLIED.md - History of fixes
- DEPLOYMENT_CHECKLIST.md - Pre-deployment checks
- Memory files in context summary

---
Generated: 2025-11-01 23:03:12
Version: v5 (Direct Storage Upload Redesign)
