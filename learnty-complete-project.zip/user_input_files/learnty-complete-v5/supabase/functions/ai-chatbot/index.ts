// Edge Function: AI Chatbot
// Provides intelligent, context-aware responses using Gemini API

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Max-Age': '86400',
}

interface Message {
  role: 'user' | 'assistant'
  content: string
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 200, headers: corsHeaders })
  }

  try {
    const { message, conversationHistory } = await req.json()

    if (!message) {
      return new Response(
        JSON.stringify({ error: { message: 'Message is required' } }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    const geminiApiKey = Deno.env.get('GEMINI_API_KEY')
    if (!geminiApiKey) {
      console.error('GEMINI_API_KEY is not set')
      return new Response(
        JSON.stringify({ error: { message: 'AI service is not configured' } }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Build conversation context for Gemini
    const systemPrompt = `You are an expert learning assistant for Learnty, a spaced repetition learning app that helps users master knowledge through books and structured learning paths.

Your role is to:
1. Explain concepts in simple, clear language (like a great teacher)
2. Help users understand app features (SRS review, learning paths, milestones)
3. Provide study tips and learning strategies
4. Answer questions about spaced repetition and the SM-2 algorithm
5. Be encouraging and supportive

Key features of Learnty:
- S3 Methodology (Small Simple Steps): Learning broken into 15-30 minute sessions
- Spaced Repetition System (SRS): Using SM-2 algorithm for optimal review timing
- Learning Paths: Structured progression through book content with milestones
- Gamification: XP rewards, achievements, progress tracking
- AI-powered content generation from uploaded books

Guidelines:
- Keep responses concise (2-4 sentences for simple questions, up to 3 paragraphs for complex topics)
- Use simple language, avoid jargon unless explaining it
- Be warm and encouraging, like a supportive teacher
- If unsure about app-specific features, acknowledge limitation and suggest general learning advice
- For learning questions, use educational techniques like elaboration, retrieval practice, and spaced repetition

Current conversation context:`

    // Format conversation history
    const conversationContext = conversationHistory
      ?.slice(-6)
      .map((msg: Message) => `${msg.role === 'user' ? 'User' : 'Assistant'}: ${msg.content}`)
      .join('\n') || ''

    // Call Gemini API
    const geminiResponse = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-lite:generateContent?key=${geminiApiKey}`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contents: [
            {
              parts: [
                {
                  text: `${systemPrompt}\n\n${conversationContext}\n\nUser: ${message}\n\nProvide a helpful, concise response:`
                }
              ]
            }
          ],
          generationConfig: {
            temperature: 0.7,
            topK: 40,
            topP: 0.95,
            maxOutputTokens: 500,
          },
        }),
      }
    )

    if (!geminiResponse.ok) {
      const errorData = await geminiResponse.text()
      console.error('Gemini API error:', errorData)
      throw new Error('Failed to get response from AI')
    }

    const geminiData = await geminiResponse.json()
    const aiResponse = geminiData.candidates?.[0]?.content?.parts?.[0]?.text || 
                      "I'm having trouble processing that. Could you rephrase your question?"

    return new Response(
      JSON.stringify({ 
        data: { 
          response: aiResponse.trim()
        } 
      }),
      { 
        status: 200, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    )
  } catch (error) {
    console.error('Error in ai-chatbot function:', error)
    
    return new Response(
      JSON.stringify({ 
        error: { 
          message: error.message || 'An unexpected error occurred',
          code: 'CHATBOT_ERROR'
        } 
      }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    )
  }
})
