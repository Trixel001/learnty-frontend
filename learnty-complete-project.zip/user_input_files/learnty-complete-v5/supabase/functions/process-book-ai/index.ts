Deno.serve(async (req) => {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Max-Age': '86400',
  };

  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { bookId, bookText } = await req.json();
    console.log(`[AI Processing] Starting for book ${bookId}, text length: ${bookText?.length || 0}`);

    if (!bookId || !bookText) {
      throw new Error('Book ID and text content are required');
    }

    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const geminiApiKey = Deno.env.get('GEMINI_API_KEY');

    if (!serviceRoleKey || !supabaseUrl) {
      throw new Error('Supabase configuration missing');
    }

    if (!geminiApiKey) {
      throw new Error('Gemini API key not configured. Please add GEMINI_API_KEY to environment variables.');
    }

    // Get user from auth header
    const authHeader = req.headers.get('authorization');
    if (!authHeader) {
      throw new Error('No authorization header');
    }

    const token = authHeader.replace('Bearer ', '');

    // Helper function to update book status
    const updateBookStatus = async (status: string, details?: any) => {
      console.log(`[AI Processing] Updating book ${bookId} status to: ${status}`);
      try {
        const updateData: any = { processing_status: status };
        if (details) {
          updateData.processing_details = details;
        }
        
        const response = await fetch(`${supabaseUrl}/rest/v1/books?id=eq.${bookId}`, {
          method: 'PATCH',
          headers: {
            'Authorization': `Bearer ${serviceRoleKey}`,
            'apikey': serviceRoleKey,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(updateData)
        });

        if (!response.ok) {
          const errorText = await response.text();
          console.error(`[AI Processing] Failed to update status: ${errorText}`);
        }
      } catch (error) {
        console.error(`[AI Processing] Error updating status:`, error);
      }
    };

    // Helper function to call Gemini API with timeout and retry
    const callGeminiAPI = async (prompt: string, maxTokens: number, maxRetries = 3): Promise<any> => {
      for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
          console.log(`[AI Processing] Gemini API attempt ${attempt}/${maxRetries}`);
          
          const controller = new AbortController();
          const timeoutId = setTimeout(() => controller.abort(), 60000); // 60 second timeout
          
          const response = await fetch(
            `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-lite:generateContent?key=${geminiApiKey}`,
            {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                contents: [{ parts: [{ text: prompt }] }],
                generationConfig: {
                  temperature: 0.7,
                  maxOutputTokens: maxTokens
                }
              }),
              signal: controller.signal
            }
          );

          clearTimeout(timeoutId);

          if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`Gemini API error: ${response.status} ${errorText}`);
          }

          const data = await response.json();
          const text = data.candidates?.[0]?.content?.parts?.[0]?.text;
          
          if (!text) {
            throw new Error('No response text from Gemini API');
          }

          return text;
        } catch (error) {
          console.error(`[AI Processing] Gemini API attempt ${attempt} failed:`, error);
          
          if (attempt === maxRetries) {
            throw error;
          }
          
          // Wait before retry (exponential backoff)
          await new Promise(resolve => setTimeout(resolve, Math.pow(2, attempt) * 1000));
        }
      }
    };

    // Chunk text if too long (max 30K tokens ~120K characters)
    const maxChars = 100000;
    const textChunk = bookText.substring(0, maxChars);

    // Update processing status
    await updateBookStatus('analyzing', { 
      startTime: new Date().toISOString(),
      textLength: textChunk.length 
    });

    // Create AI prompts
    const summaryPrompt = `Analyze this book content and provide a JSON response with:
1. title: Extracted title
2. author: Extracted author name
3. summary: 2-3 sentence summary
4. topics: Array of main topics/subjects (max 5)
5. difficulty: Learning difficulty level (beginner/intermediate/advanced)
6. estimatedMinutes: Estimated reading time in minutes
7. learningObjectives: Array of key learning objectives (3-5 points)
8. genre: Book genre/category

Content preview: ${textChunk.substring(0, 8000)}

Return only valid JSON, no markdown formatting.`;

    const chapterPrompt = `Analyze this book and break it down into logical learning sections. Provide a JSON array where each object has:
1. chapterNumber: Sequential number
2. title: Chapter/section title
3. summary: Brief summary
4. learningObjectives: Array of objectives for this section
5. difficultyLevel: beginner/intermediate/advanced
6. estimatedMinutes: Time needed for this section

Content preview: ${textChunk.substring(0, 8000)}

Return only valid JSON array, no markdown formatting. Aim for 5-8 chapters.`;

    // Update to processing_chapters status
    await updateBookStatus('processing_chapters', { 
      stage: 'calling_ai_apis',
      timestamp: new Date().toISOString() 
    });

    // Call Gemini APIs with retry logic
    console.log('[AI Processing] Starting parallel AI analysis...');
    const [summaryText, chapterText] = await Promise.all([
      callGeminiAPI(summaryPrompt, 2048),
      callGeminiAPI(chapterPrompt, 3072)
    ]);

    console.log('[AI Processing] AI analysis complete, parsing responses...');

    // Parse responses
    let analysis;
    let chapters = [];
    
    try {
      // Parse summary response
      const cleanSummaryText = summaryText.replace(/```json\n?|\n?```/g, '').trim();
      analysis = JSON.parse(cleanSummaryText);
      console.log('[AI Processing] Summary parsed successfully');
    } catch (e) {
      console.error('[AI Processing] Failed to parse summary:', e);
      throw new Error(`Failed to parse AI summary response: ${e.message}`);
    }

    // Parse chapter response
    try {
      const cleanChapterText = chapterText.replace(/```json\n?|\n?```/g, '').trim();
      chapters = JSON.parse(cleanChapterText);
      console.log(`[AI Processing] Chapters parsed successfully: ${chapters.length} chapters`);
    } catch (e) {
      console.error('[AI Processing] Failed to parse chapters:', e);
      // Don't fail the whole process if chapters fail
      chapters = [];
    }

    // Update book with AI analysis
    console.log('[AI Processing] Updating book with AI analysis...');
    const updateResponse = await fetch(`${supabaseUrl}/rest/v1/books?id=eq.${bookId}`, {
      method: 'PATCH',
      headers: {
        'Authorization': `Bearer ${serviceRoleKey}`,
        'apikey': serviceRoleKey,
        'Content-Type': 'application/json',
        'Prefer': 'return=representation'
      },
      body: JSON.stringify({
        title: analysis.title || 'Unknown',
        author: analysis.author || 'Unknown',
        genre: analysis.genre || 'General',
        processing_status: 'completed',
        processing_details: {
          completedAt: new Date().toISOString(),
          chaptersGenerated: chapters.length,
          aiAnalysisSuccess: true
        },
        ai_analysis: {
          summary: analysis.summary,
          topics: analysis.topics || [],
          difficulty: analysis.difficulty || 'intermediate',
          estimatedMinutes: analysis.estimatedMinutes || 60,
          learningObjectives: analysis.learningObjectives || [],
          processedAt: new Date().toISOString()
        }
      })
    });

    if (!updateResponse.ok) {
      const errorText = await updateResponse.text();
      throw new Error(`Failed to update book: ${errorText}`);
    }

    const updatedBooks = await updateResponse.json();
    console.log('[AI Processing] Book updated successfully');

    // Insert chapters if available
    let actualChaptersCreated = 0;
    let chapterInsertError = null;
    
    if (chapters.length > 0) {
      try {
        console.log(`[AI Processing] Inserting ${chapters.length} chapters...`);
        
        // Get user ID from token
        const userResponse = await fetch(`${supabaseUrl}/auth/v1/user`, {
          headers: {
            'Authorization': `Bearer ${token}`,
            'apikey': serviceRoleKey
          }
        });

        if (!userResponse.ok) {
          throw new Error(`Failed to get user data: ${userResponse.status} ${userResponse.statusText}`);
        }

        const userData = await userResponse.json();
        const userId = userData.id;

        const chaptersToInsert = chapters.map((chapter, index) => ({
          book_id: bookId,
          user_id: userId,
          chapter_number: chapter.chapterNumber || index + 1,
          title: chapter.title || `Chapter ${index + 1}`,
          summary: chapter.summary || '',
          learning_objectives: chapter.learningObjectives || [],
          difficulty_level: chapter.difficultyLevel || 'intermediate',
          estimated_minutes: chapter.estimatedMinutes || 30
        }));

        const chaptersInsertResponse = await fetch(`${supabaseUrl}/rest/v1/book_chapters`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${serviceRoleKey}`,
            'apikey': serviceRoleKey,
            'Content-Type': 'application/json',
            'Prefer': 'return=representation'
          },
          body: JSON.stringify(chaptersToInsert)
        });

        if (!chaptersInsertResponse.ok) {
          const errorText = await chaptersInsertResponse.text();
          const errorMsg = `Chapter insertion failed: ${chaptersInsertResponse.status} ${chaptersInsertResponse.statusText} - ${errorText}`;
          console.error(`[AI Processing] ${errorMsg}`);
          chapterInsertError = errorMsg;
        } else {
          const insertedChapters = await chaptersInsertResponse.json();
          actualChaptersCreated = insertedChapters.length;
          console.log(`[AI Processing] Successfully inserted ${actualChaptersCreated} chapters`);
        }
      } catch (error) {
        const errorMsg = `Chapter insertion error: ${error.message}`;
        console.error(`[AI Processing] ${errorMsg}`);
        chapterInsertError = errorMsg;
      }
    }

    console.log(`[AI Processing] Process completed for book ${bookId}`);
    return new Response(JSON.stringify({
      data: {
        book: updatedBooks[0],
        analysis,
        chaptersGenerated: chapters.length,
        chaptersCreated: actualChaptersCreated,
        chapterInsertError: chapterInsertError,
        processingTime: new Date().toISOString()
      }
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('[AI Processing] Error:', error);

    // Try to update status to failed
    try {
      const { bookId } = await req.json().catch(() => ({}));
      if (bookId) {
        const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
        const supabaseUrl = Deno.env.get('SUPABASE_URL');
        
        if (serviceRoleKey && supabaseUrl) {
          await fetch(`${supabaseUrl}/rest/v1/books?id=eq.${bookId}`, {
            method: 'PATCH',
            headers: {
              'Authorization': `Bearer ${serviceRoleKey}`,
              'apikey': serviceRoleKey,
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({ 
              processing_status: 'failed',
              processing_details: {
                error: error.message,
                failedAt: new Date().toISOString()
              }
            })
          });
        }
      }
    } catch (updateError) {
      console.error('[AI Processing] Failed to update error status:', updateError);
    }

    return new Response(JSON.stringify({
      error: {
        code: 'AI_PROCESSING_FAILED',
        message: error.message,
        timestamp: new Date().toISOString()
      }
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});