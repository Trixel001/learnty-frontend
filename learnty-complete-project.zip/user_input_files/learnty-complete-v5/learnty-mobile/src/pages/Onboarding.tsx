import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuthStore } from '@/store/auth'
import { GraduationCap, Brain, Hammer, TrendingUp, ChevronRight, X } from 'lucide-react'

const slides = [
  {
    title: 'Welcome to Learnty',
    subtitle: 'Your AI-powered learning companion',
    description: 'Transform books into interactive learning experiences using cognitive science principles.',
    icon: GraduationCap,
    gradient: 'from-blue-500 to-purple-600'
  },
  {
    title: 'Learn with Science',
    subtitle: "Based on Dehaene's Four Pillars",
    description: 'Attention, Active Engagement, Error Feedback, and Consolidation - all built into your learning journey.',
    icon: Brain,
    gradient: 'from-purple-500 to-pink-600'
  },
  {
    title: 'Build Projects, Not Notes',
    subtitle: 'Apply knowledge through projects',
    description: 'Break down learning into small, simple steps (S3) with AI-generated milestones.',
    icon: Hammer,
    gradient: 'from-pink-500 to-orange-600'
  },
  {
    title: 'Master Through Practice',
    subtitle: 'Spaced repetition system',
    description: 'Active recall with confidence-based reviews ensures long-term retention.',
    icon: TrendingUp,
    gradient: 'from-orange-500 to-red-600'
  }
]

export default function Onboarding() {
  const [currentSlide, setCurrentSlide] = useState(0)
  const navigate = useNavigate()
  const completeOnboarding = useAuthStore(state => state.completeOnboarding)

  const handleNext = () => {
    if (currentSlide < slides.length - 1) {
      setCurrentSlide(currentSlide + 1)
    } else {
      completeOnboarding()
      navigate('/auth')
    }
  }

  const handleSkip = () => {
    completeOnboarding()
    navigate('/auth')
  }

  const slide = slides[currentSlide]
  const Icon = slide.icon

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex flex-col">
      {/* Skip button */}
      {currentSlide < slides.length - 1 && (
        <div className="absolute top-4 right-4 z-10">
          <button
            onClick={handleSkip}
            className="p-2 text-gray-600 hover:text-gray-900 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>
      )}

      {/* Slide content */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 py-12">
        <div className={`w-32 h-32 rounded-full bg-gradient-to-br ${slide.gradient} flex items-center justify-center mb-8 shadow-lg`}>
          <Icon className="w-16 h-16 text-white" />
        </div>

        <h1 className="text-3xl md:text-4xl font-bold text-gray-900 text-center mb-4">
          {slide.title}
        </h1>
        
        <p className="text-lg md:text-xl font-semibold text-blue-600 text-center mb-4">
          {slide.subtitle}
        </p>
        
        <p className="text-base md:text-lg text-gray-600 text-center max-w-md leading-relaxed">
          {slide.description}
        </p>
      </div>

      {/* Progress indicators */}
      <div className="flex justify-center gap-2 mb-8">
        {slides.map((_, index) => (
          <div
            key={index}
            className={`h-2 rounded-full transition-all duration-300 ${
              index === currentSlide
                ? 'w-8 bg-blue-600'
                : 'w-2 bg-gray-300'
            }`}
          />
        ))}
      </div>

      {/* Next/Get Started button */}
      <div className="px-6 pb-8">
        <button
          onClick={handleNext}
          className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-4 rounded-xl font-semibold text-lg shadow-lg hover:shadow-xl transition-all duration-300 flex items-center justify-center gap-2 active:scale-95"
        >
          {currentSlide < slides.length - 1 ? (
            <>
              Continue
              <ChevronRight className="w-5 h-5" />
            </>
          ) : (
            'Get Started'
          )}
        </button>
      </div>
    </div>
  )
}
