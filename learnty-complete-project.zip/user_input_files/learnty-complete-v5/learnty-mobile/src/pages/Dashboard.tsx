import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { useNavigate } from 'react-router-dom'
import { useAuthStore } from '@/store/auth'
import { supabase } from '@/lib/supabase'
import { 
  getWeeklyLearningData,
  getDailyActivity,
  getAllAchievements,
  getDueCardsCount,
  getActiveProjectsCount
} from '@/lib/dashboardData'
import { 
  Flame, 
  Star, 
  TrendingUp, 
  Upload, 
  Brain, 
  Timer, 
  FolderOpen, 
  BookOpen,
  Plus
} from 'lucide-react'
import ProgressRing from '@/components/ProgressRing'
import StreakCalendar from '@/components/StreakCalendar'
import LearningChart from '@/components/LearningChart'
import AchievementGallery from '@/components/AchievementGallery'


interface Achievement {
  id: string
  title: string
  description: string
  icon: string
  earned: boolean
  earnedAt?: string
  progress?: number
  total?: number
}

export default function Dashboard() {
  const { profile, user, loadProfile, loadAchievements } = useAuthStore()
  const navigate = useNavigate()
  const [weeklyData, setWeeklyData] = useState<Array<{ day: string; minutes: number }>>([])
  const [recentActivity, setRecentActivity] = useState<boolean[]>([])
  const [allAchievements, setAllAchievements] = useState<Achievement[]>([])
  const [dueCardsCount, setDueCardsCount] = useState(0)
  const [activeProjectsCount, setActiveProjectsCount] = useState(0)
  const [showFab, setShowFab] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    if (user?.id) {
      loadDashboardData()
      loadProfile()
      loadAchievements()
      
      // Subscribe to profile changes for real-time updates
      const channel = supabase
        .channel('profile-changes')
        .on(
          'postgres_changes',
          {
            event: 'UPDATE',
            schema: 'public',
            table: 'profiles',
            filter: `id=eq.${user.id}`
          },
          () => {
            loadProfile()
            loadDashboardData()
          }
        )
        .subscribe()

      // Show FAB after slight delay
      setTimeout(() => {
        setShowFab(true)
      }, 500)

      return () => {
        supabase.removeChannel(channel)
      }
    }
  }, [user?.id, loadProfile, loadAchievements])

  const loadDashboardData = async () => {
    if (!user?.id) return
    
    try {
      setIsLoading(true)
      
      // Load all data in parallel
      const [weekly, activity, achievements, dueCards, activeProjects] = await Promise.all([
        getWeeklyLearningData(user.id),
        getDailyActivity(user.id),
        getAllAchievements(user.id),
        getDueCardsCount(user.id),
        getActiveProjectsCount(user.id)
      ])
      
      setWeeklyData(weekly)
      setRecentActivity(activity)
      setAllAchievements(achievements)
      setDueCardsCount(dueCards)
      setActiveProjectsCount(activeProjects)
    } catch (error) {
      console.error('Error loading dashboard data:', error)
    } finally {
      setIsLoading(false)
    }
  }

  // Calculate progress to next level
  const currentLevelXP = profile?.total_xp || 0
  const xpForNextLevel = (profile?.level || 1) * 100 // Simple formula: level * 100
  const progressToNextLevel = (currentLevelXP % xpForNextLevel) / xpForNextLevel * 100

  const stats = [
    {
      icon: Flame,
      label: 'Streak',
      value: profile?.streak_count || 0,
      unit: 'days',
      color: '#f97316',
      progress: Math.min((profile?.streak_count || 0) / 30 * 100, 100)
    },
    {
      icon: Star,
      label: 'Total XP',
      value: profile?.total_xp || 0,
      unit: 'XP',
      color: '#3b82f6',
      progress: progressToNextLevel
    },
    {
      icon: TrendingUp,
      label: 'Level',
      value: profile?.level || 1,
      unit: '',
      color: '#10b981',
      progress: progressToNextLevel
    }
  ]

  const quickActions = [
    {
      icon: Upload,
      title: 'Upload Book',
      subtitle: 'Start learning from a new book',
      color: 'from-blue-500 to-purple-500',
      path: '/books',
      badge: null
    },
    {
      icon: Brain,
      title: 'Review Cards',
      subtitle: 'Practice with flashcards',
      color: 'from-purple-500 to-pink-500',
      path: '/review',
      badge: dueCardsCount > 0 ? `${dueCardsCount} due` : null
    },
    {
      icon: Timer,
      title: 'Focus Session',
      subtitle: 'Start a Pomodoro timer',
      color: 'from-green-500 to-emerald-500',
      path: '/focus',
      badge: null
    },
    {
      icon: FolderOpen,
      title: 'My Projects',
      subtitle: 'Continue your projects',
      color: 'from-orange-500 to-red-500',
      path: '/projects',
      badge: activeProjectsCount > 0 ? `${activeProjectsCount} active` : null
    }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 pb-24">
      {/* Header with gradient */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-r from-blue-600 to-purple-600 px-4 sm:px-6 pt-8 sm:pt-12 pb-20 sm:pb-24 rounded-b-3xl shadow-lg"
      >
        <div className="flex items-center gap-3 sm:gap-4 mb-4 sm:mb-6">
          <motion.div 
            whileHover={{ scale: 1.05 }}
            className="w-12 h-12 sm:w-16 sm:h-16 rounded-full bg-white/20 flex items-center justify-center overflow-hidden"
          >
            {profile?.avatar_url ? (
              <img src={profile.avatar_url} alt="Avatar" className="w-full h-full object-cover" />
            ) : (
              <div className="text-white text-lg sm:text-2xl font-bold">
                {profile?.full_name?.charAt(0) || 'U'}
              </div>
            )}
          </motion.div>
          <div className="flex-1">
            <motion.h1 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="text-xl sm:text-2xl font-bold text-white"
            >
              Welcome back, {profile?.full_name || 'Learner'}!
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
              className="text-white/80 text-sm sm:text-base"
            >
              Level {profile?.level || 1} - {profile?.total_xp || 0} XP
            </motion.p>
          </div>
        </div>

        {/* Motivational Quote */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-white/10 backdrop-blur-sm rounded-2xl p-4"
        >
          <p className="text-white/90 text-sm italic text-center">
            "The capacity to learn is a gift; the ability to learn is a skill; the willingness to learn is a choice."
          </p>
        </motion.div>
      </motion.div>

      {/* Progress Rings */}
      <div className="px-4 sm:px-6 -mt-16 mb-6">
        <div className="grid grid-cols-3 gap-2 sm:gap-3">
          {stats.map((stat, index) => {
            const Icon = stat.icon
            return (
              <motion.div 
                key={stat.label}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.05 }}
                className="bg-white rounded-2xl p-3 sm:p-4 shadow-lg"
              >
                <ProgressRing 
                  progress={stat.progress} 
                  size={80}
                  strokeWidth={5}
                  color={stat.color}
                >
                  <div className="flex flex-col items-center">
                    <Icon className="w-4 h-4 sm:w-5 sm:h-5 mb-1" style={{ color: stat.color }} />
                    <div className="text-base sm:text-lg font-bold text-gray-900">
                      {stat.value}
                    </div>
                  </div>
                </ProgressRing>
                <div className="text-xs text-gray-600 text-center mt-1 sm:mt-2">
                  {stat.label}
                </div>
              </motion.div>
            )
          })}
        </div>
      </div>

      {/* Streak Calendar */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="px-4 sm:px-6 mb-4 sm:mb-6"
      >
        <StreakCalendar 
          streakCount={profile?.streak_count || 0} 
          recentActivity={recentActivity}
        />
      </motion.div>

      {/* Learning Chart */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="px-4 sm:px-6 mb-4 sm:mb-6"
      >
        <LearningChart 
          data={weeklyData} 
          title="This Week's Learning Time"
        />
      </motion.div>

      {/* Achievement Gallery */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7 }}
        className="px-4 sm:px-6 mb-4 sm:mb-6"
      >
        <AchievementGallery achievements={allAchievements} />
      </motion.div>

      {/* Quick Actions */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8 }}
        className="px-4 sm:px-6 mb-4 sm:mb-6"
      >
        <h2 className="text-lg sm:text-xl font-bold text-gray-900 mb-3 sm:mb-4">Quick Actions</h2>
        <div className="grid grid-cols-2 gap-2 sm:gap-3 md:grid-cols-4">
          {quickActions.map((action, index) => {
            const Icon = action.icon
            return (
              <motion.button
                key={action.title}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.8 + index * 0.05 }}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => navigate(action.path)}
                className="bg-white rounded-2xl p-3 sm:p-4 shadow-lg text-left hover:shadow-xl transition-all relative overflow-hidden"
              >
                <div className={`w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-gradient-to-br ${action.color} flex items-center justify-center mb-2 sm:mb-3`}>
                  <Icon className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-1 text-sm sm:text-base">{action.title}</h3>
                <p className="text-xs sm:text-sm text-gray-600">{action.subtitle}</p>
                {action.badge && (
                  <div className="absolute top-2 right-2 bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded-full font-medium">
                    {action.badge}
                  </div>
                )}
              </motion.button>
            )
          })}
        </div>
      </motion.div>



      {/* Floating Action Button */}
      {showFab && (
        <motion.button
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => navigate('/books')}
          className="fixed bottom-20 sm:bottom-24 right-4 sm:right-6 w-12 h-12 sm:w-14 sm:h-14 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full shadow-xl flex items-center justify-center z-40"
        >
          <Plus className="w-6 h-6 sm:w-7 sm:h-7 text-white" />
        </motion.button>
      )}
    </div>
  )
}
